# -*- coding: utf-8 -*-
import os
import pyodbc
import openpyxl
import shutil
import time
import json
import sys
import threading
from openpyxl.worksheet.datavalidation import DataValidation
from typing import Dict, Set, Tuple

# ==============================================================================
# --- CONSTANTES E CONFIGURAÇÕES ---
# ==============================================================================
ARQUIVO_CONEXAO = 'conexao_temp.txt'
TEMPLATE_LIMPO_NOME = "Cadastros Auto Nextt limpa.xlsx"
NOVO_ARQUIVO_NOME = "Cadastros Auto Nextt.xlsx"

# Nomes das abas a serem processadas
ABAS_PARA_ATUALIZAR_TITULO = [
    "Cadastro de Produtos", "Cadastro de Pedidos", "Cadastro de Marcas",
    "Cadastro de Segmento", "Cadastro de Secao", "Cadastro de Especie"
]

# Configurações da aba "Cadastro de Produtos"
ABA_PRODUTOS = "Cadastro de Produtos"
LINHA_TITULO_PRODUTOS = 3
LINHA_OBRIGATORIO_PRODUTOS = 4
CELULA_TITULO_EMPRESA = 'A2'
MAX_LINHAS_VALIDACAO = 1007 # Linha 7 até 1007
INTERVALO_VALIDACAO_ESPECIE = f'B7:B{MAX_LINHAS_VALIDACAO}'
FORMULA_VALIDACAO_ESPECIE = f'=INDIRECT("\'Dados Consolidados\'!SecaoCompleta"&BC7)' # Note que o openpyxl ajusta o '7' para cada linha do intervalo

# Mapeamento de colunas do DB para nomes no Excel
MAPEAMENTO_COLUNAS_PRODUTO: Dict[str, str] = {
    "sec_codigo": "Seção",
    "esp_codigo": "Espécie",
    "prd_descricao": "Descrição",
    "prd_descricao_reduzida": "Descrição Reduzida",
    "mar_codigo": "Marca",
    "prd_referencia_fornec": "Referência do Fornecedor",
    "prd_codigo_original": "Código Original",
    "usu_codigo_comprador": "Comprador",
    "und_codigo": "Unidade",
    "clf_codigo": "Classificação Fiscal",
    "prd_origem": "Origem",
    "prd_valor_venda": "Valor de Venda",
    "prd_percentual_icms": "% ICMS",
    "prd_percentual_ipi": "% IPI",
    "etq_codigo_padrao": "Etiqueta Padrão"
}

# Colunas que, apesar de poderem ser nulas no DB, são tratadas como obrigatórias na planilha
COLUNAS_FORCADAS_OBRIGATORIAS: Set[str] = {"und_codigo", "clf_codigo", "prd_origem"}

# ==============================================================================
# --- FUNÇÕES AUXILIARES E DE CONEXÃO ---
# ==============================================================================
class ProcessCancelledError(Exception):
    """Exceção customizada para interrupção de processo."""
    pass

def recurso_path(rel_path: str) -> str:
    """Garante que o caminho do recurso funcione tanto em modo script quanto em executável."""
    try:
        base_path = sys._MEIPASS
    except AttributeError:
        base_path = os.path.abspath(".")
    return os.path.join(base_path, rel_path)

def _check_cancelled(event: threading.Event):
    """Verifica se o evento de cancelamento foi acionado e levanta uma exceção."""
    if event.is_set():
        raise ProcessCancelledError("Processo cancelado pelo usuário.")

def get_db_connection() -> pyodbc.Connection:
    """Lê o arquivo de configuração e retorna um objeto de conexão pyodbc."""
    file_path = recurso_path(ARQUIVO_CONEXAO)
    with open(file_path, 'r') as f:
        config = json.load(f)

    if config.get('trusted_connection', 'no').lower() == 'yes':
        conn_str = f"DRIVER={{{config['driver']}}};SERVER={config['server']};DATABASE={config['database']};Trusted_Connection=yes"
    else:
        conn_str = f"DRIVER={{{config['driver']}}};SERVER={config['server']};DATABASE={config['database']};UID={config['username']};PWD={config['password']}"
    
    return pyodbc.connect(conn_str)

def _fetch_database_info(cursor: pyodbc.Cursor) -> Tuple[str, Set[str], Set[str]]:
    """Busca todas as informações necessárias do banco de dados de uma só vez."""
    # Nome da empresa
    cursor.execute("SELECT TOP 1 emp_descricao FROM tb_empresa WITH(NOLOCK)")
    empresa_nome = cursor.fetchone()[0]

    # Colunas obrigatórias de tb_produto
    cursor.execute("SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'tb_produto' AND IS_NULLABLE = 'NO'")
    colunas_obrigatorias_produto = {row.COLUMN_NAME for row in cursor.fetchall()}
    colunas_obrigatorias_produto.update(COLUNAS_FORCADAS_OBRIGATORIAS)

    # Colunas obrigatórias de tb_atributo_produto (para checagem simples)
    cursor.execute("SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'tb_atributo_produto' AND IS_NULLABLE = 'NO'")
    colunas_obrigatorias_atributo = {row.COLUMN_NAME for row in cursor.fetchall()}

    return empresa_nome, colunas_obrigatorias_produto, colunas_obrigatorias_atributo

# ==============================================================================
# --- FUNÇÕES DE MANIPULAÇÃO DA PLANILHA ---
# ==============================================================================

def _update_sheet_titles(workbook: openpyxl.Workbook, empresa_nome: str, event: threading.Event):
    """Atualiza o título em abas específicas da planilha."""
    print("Atualizando títulos das abas...")
    for nome_aba in ABAS_PARA_ATUALIZAR_TITULO:
        _check_cancelled(event)
        try:
            aba = workbook[nome_aba]
            termo_cadastro = nome_aba.split(' ')[-1] # Pega "Produtos", "Pedidos", etc.
            aba[CELULA_TITULO_EMPRESA] = f"Cadastro de {termo_cadastro} {empresa_nome}"
        except KeyError:
            print(f"AVISO: A aba '{nome_aba}' não foi encontrada e será ignorada.")

def _mark_required_columns(workbook: openpyxl.Workbook, required_cols: Set[str], required_attr_cols: Set[str], event: threading.Event):
    """Marca as colunas obrigatórias na aba 'Cadastro de Produtos'."""
    print("Identificando e marcando colunas obrigatórias...")
    try:
        sheet = workbook[ABA_PRODUTOS]
    except KeyError:
        print(f"ERRO: Aba '{ABA_PRODUTOS}' essencial não encontrada.")
        return

    # --- INÍCIO DA CORREÇÃO ---
    # É necessário desmesclar as células na linha de 'Obrigatório' antes de escrever nelas.
    # Criamos uma lista dos intervalos a serem desfeitos para evitar modificar a lista enquanto iteramos sobre ela.
    merged_ranges_to_unmerge = []
    for merged_range in sheet.merged_cells.ranges:
        if LINHA_OBRIGATORIO_PRODUTOS >= merged_range.min_row and LINHA_OBRIGATORIO_PRODUTOS <= merged_range.max_row:
            merged_ranges_to_unmerge.append(str(merged_range))
    
    if merged_ranges_to_unmerge:
        print(f"Desmesclando células na linha {LINHA_OBRIGATORIO_PRODUTOS} para edição...")
        for range_str in merged_ranges_to_unmerge:
            sheet.unmerge_cells(range_str)
    # --- FIM DA CORREÇÃO ---

    # Mapeamento reverso para busca rápida: Nome Excel -> Nome DB
    excel_to_db_map = {v: k for k, v in MAPEAMENTO_COLUNAS_PRODUTO.items()}

    for col in range(1, sheet.max_column + 1):
        _check_cancelled(event)
        # Acessa a célula de cabeçalho (que pode ser uma MergedCell)
        header_cell = sheet.cell(row=LINHA_TITULO_PRODUTOS, column=col)
        header_name = header_cell.value

        if header_name and header_name in excel_to_db_map:
            db_col_name = excel_to_db_map[header_name]
            if db_col_name in required_cols:
                # Agora, escrever na célula da linha 4 funcionará, pois ela não está mais mesclada.
                sheet.cell(row=LINHA_OBRIGATORIO_PRODUTOS, column=col, value="Obrigatorio")

    # Marca a coluna de atributo se necessário
    if 'apr_descricao' in required_attr_cols:
        # Coluna Z = 26
        sheet.cell(row=LINHA_OBRIGATORIO_PRODUTOS, column=26, value="Obrigatorio")

def _apply_data_validations(workbook: openpyxl.Workbook, event: threading.Event):
    """Aplica a validação de dados para a coluna de espécies de forma otimizada."""
    print("Atualizando validação de dados para espécies...")
    try:
        sheet = workbook[ABA_PRODUTOS]
    except KeyError:
        print(f"ERRO: Aba '{ABA_PRODUTOS}' essencial não encontrada.")
        return

    _check_cancelled(event)
    
    # Cria a regra de validação uma única vez
    dv = DataValidation(type="list", formula1=FORMULA_VALIDACAO_ESPECIE, allow_blank=True)
    dv.error = "Por favor, selecione um valor da lista dependente da Seção."
    dv.errorTitle = "Valor Inválido"
    dv.showErrorMessage = True
    
    # Adiciona a regra à planilha
    sheet.add_data_validation(dv)
    
    # Aplica a regra a todo o intervalo de células de uma vez
    dv.add(INTERVALO_VALIDACAO_ESPECIE)


# ==============================================================================
# --- FUNÇÃO PRINCIPAL ---
# ==============================================================================

def preencher_planilha(caminho_template: str, cancelar_evento: threading.Event):
    """
    Orquestra o processo de criação e preenchimento da planilha de cadastros.
    
    Args:
        caminho_template (str): Caminho para o arquivo de modelo limpo.
        cancelar_evento (threading.Event): Evento para monitorar o cancelamento do processo.
    """
    inicio_total = time.time()
    caminho_template_abs = recurso_path(caminho_template)
    caminho_novo_arquivo = os.path.join(os.path.dirname(caminho_template_abs), NOVO_ARQUIVO_NOME)
    
    try:
        _check_cancelled(cancelar_evento)
        
        print(f"Copiando template de '{caminho_template_abs}' para '{caminho_novo_arquivo}'...")
        shutil.copy(caminho_template_abs, caminho_novo_arquivo)
        
        # Conecta ao banco e busca todas as informações necessárias
        with get_db_connection() as conn:
            cursor = conn.cursor()
            empresa, required_cols_prod, required_cols_attr = _fetch_database_info(cursor)
        
        _check_cancelled(cancelar_evento)
        
        print("Carregando a nova planilha para edição...")
        workbook = openpyxl.load_workbook(caminho_novo_arquivo)
        
        # Executa as etapas de manipulação da planilha
        _update_sheet_titles(workbook, empresa, cancelar_evento)
        _mark_required_columns(workbook, required_cols_prod, required_cols_attr, cancelar_evento)
        _apply_data_validations(workbook, cancelar_evento)
        
        _check_cancelled(cancelar_evento)

        print("Salvando as alterações na planilha... (Isso pode levar um momento)")
        workbook.save(caminho_novo_arquivo)
        print("Planilha salva com sucesso!")

    except ProcessCancelledError as e:
        print(f"\nOPERAÇÃO CANCELADA: {e}")
    except FileNotFoundError:
        print(f"ERRO FATAL: O arquivo de template '{caminho_template_abs}' não foi encontrado.")
    except pyodbc.Error as e:
        print(f"ERRO DE BANCO DE DADOS: Não foi possível conectar ou executar a consulta. Detalhes: {e}")
    except Exception as e:
        import traceback
        print(f"ERRO INESPERADO: Ocorreu um problema durante o processo. Detalhes: {e}")
        traceback.print_exc()
    finally:
        tempo_total = time.time() - inicio_total
        print(f"\nTempo total de execução: {tempo_total:.2f} segundos.")

# ==============================================================================
# --- BLOCO DE EXECUÇÃO PARA TESTE ---
# ==============================================================================
if __name__ == '__main__':
    print("Iniciando teste da função 'preencher_planilha'.")
    
    # Simula o ambiente de execução da aplicação principal
    # 1. Crie um arquivo 'conexao_temp.txt' no mesmo diretório
    # 2. Crie um arquivo 'Cadastros Auto Nextt limpa.xlsx'
    
    # Evento de cancelamento para teste
    evento_de_cancelamento = threading.Event()

    # Exemplo de como cancelar o processo após 5 segundos
    # timer = threading.Timer(5, lambda: evento_de_cancelamento.set())
    # timer.start()
    
    if not os.path.exists(recurso_path(TEMPLATE_LIMPO_NOME)):
        print(f"\nERRO: Arquivo de template '{TEMPLATE_LIMPO_NOME}' não encontrado.")
        print("Crie um arquivo excel com este nome para poder testar.")
    elif not os.path.exists(recurso_path(ARQUIVO_CONEXAO)):
        print(f"\nERRO: Arquivo de conexão '{ARQUIVO_CONEXAO}' não encontrado.")
    else:
        preencher_planilha(TEMPLATE_LIMPO_NOME, evento_de_cancelamento)