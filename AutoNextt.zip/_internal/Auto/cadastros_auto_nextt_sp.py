import pandas as pd
import pyodbc
import os
import json
import sys
import openpyxl
import time
import warnings
import logging
from datetime import datetime
from openpyxl.utils import get_column_letter, column_index_from_string
from contextlib import contextmanager
from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional, Tuple

# --- Configurações Globais ---
DEBUG = True
BATCH_SIZE = 100
ARQUIVO_CONEXAO = 'conexao_temp.txt'

# --- Configuração de Logging ---
log_formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
log_file = 'log_importacao.txt'
logger = logging.getLogger()
if logger.hasHandlers():
    logger.handlers.clear()
file_handler = logging.FileHandler(log_file, mode='w', encoding='utf-8')
file_handler.setFormatter(log_formatter)
logger.addHandler(file_handler)
if sys.stdout is not None:
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(log_formatter)
    logger.addHandler(console_handler)
logger.setLevel(logging.DEBUG if DEBUG else logging.INFO)
warnings.filterwarnings("ignore", category=UserWarning, module="openpyxl")

# --- Constantes de Planilha para PRODUTOS ---
PRODUTO_SHEET_NAME = "Cadastro de Produtos"
PRODUTO_HEADER_ROW = 3
PRODUTO_DATA_START_ROW = 7
PRODUTO_COL_INICIAL_ADICIONAIS = 'BD'
PRODUTO_COL_LIMITE_ADICIONAIS = 'CF'
PRODUTO_COLS_CORES = ['R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'AA', 'AB', 'AC', 'AD', 'AE', 'AF', 'AG', 'AH', 'AI', 'AJ']
PRODUTO_COLS_TAMANHOS = ['AK', 'AL', 'AM', 'AN', 'AO', 'AP', 'AQ', 'AR', 'AS', 'AT', 'AU', 'AV', 'AW', 'AX', 'AY', 'AZ', 'BA', 'BB', 'BC']

# --- Constantes de SQL para PRODUTOS ---
SQL_GET_TPA_CODIGOS = "SELECT tpa_codigo FROM tb_tipo_atributo WITH(NOLOCK) WHERE tpa_codigo > 2 AND tba_codigo = 1 AND tpa_ordem = 0 ORDER BY tpa_codigo;"
SQL_CLEAN_AUX_ITEM = "DELETE FROM aux_item_produto WHERE usu_codigo = ?;"
SQL_CLEAN_AUX_ATTR_ITEM = "DELETE FROM aux_atributo_item_produto WHERE usu_codigo = ?;"
SQL_CLEAN_AUX_ATTR_PROD = "DELETE FROM aux_atributo_produto WHERE usu_codigo = ?;"
SQL_INSERT_AUX_ITEM_PRODUTO = "INSERT INTO aux_item_produto (usu_codigo, ipr_codigo, ipr_codigo_barra, ipr_preco_promocional, sec_codigo, esp_codigo, prd_codigo) VALUES (?, ?, ?, ?, ?, ?, ?);"
SQL_INSERT_AUX_ATRIBUTO_ITEM = "INSERT INTO aux_atributo_item_produto (usu_codigo, ipr_codigo, tpa_codigo, aip_descricao, aip_ordem) VALUES (?, ?, ?, ?, ?);"
SQL_INSERT_AUX_ATRIBUTO_PRODUTO = "INSERT INTO aux_atributo_produto (usu_codigo, tpa_codigo, apr_descricao) VALUES (?, ?, ?);"
SQL_GET_PRODUTO_PARA_COMPARACAO = "SELECT prd_descricao, prd_descricao_reduzida, mar_codigo, prd_referencia_fornec, prd_codigo_original, usu_codigo_comprador, und_codigo, clf_codigo, prd_origem, etq_codigo_padrao, prd_valor_venda, prd_aliquota_icms, prd_percentual_ipi FROM tb_produto WITH(NOLOCK) WHERE sec_codigo=? AND esp_codigo=? AND prd_codigo=?;"
SQL_GET_ATRIBUTOS_PRODUTO = "SELECT tpa_codigo, apr_descricao FROM tb_atributo_produto WITH(NOLOCK) WHERE sec_codigo = ? AND esp_codigo = ? AND prd_codigo = ?;"
SQL_GET_ATRIBUTOS_ITEM_PRODUTO = "SELECT tpa_codigo, aip_descricao FROM tb_atributo_item_produto WITH(NOLOCK) WHERE sec_codigo = ? AND esp_codigo = ? AND prd_codigo = ?;"
SQL_EXEC_PR_PRODUTO_I = """
    SET NOCOUNT ON;
    DECLARE @prd_codigo_out CODIGO;
    EXEC dbo.pr_produto_i 
        @usu_codigo = ?, @sec_codigo = ?, @esp_codigo = ?, @prd_codigo = @prd_codigo_out OUTPUT,
        @prd_descricao = ?, @prd_descricao_reduzida = ?, @mar_codigo = ?, @prd_data_cadastro = ?,
        @prd_unidade = ?, @prd_data_ultima_compra = ?, @prd_data_ultima_entrega = ?,
        @prd_custo_medio = ?, @prd_ultimo_custo = ?, @prd_preco_medio = ?, @prd_aliquota_icms = ?,
        @prd_codigo_original = ?, @prd_ativo = ?, @prd_arquivo_foto = ?, @prd_referencia_fornec = ?,
        @clf_codigo = ?, @usu_codigo_comprador = ?, @und_codigo = ?, @prd_valor_venda = ?,
        @prd_origem = ?, @prd_percentual_icms = ?, @prd_percentual_ipi = ?, @etq_codigo_padrao = ?,
        @prd_permite_comprar = ?, @udc_codigo = ?, @prd_valor_unidade_conversao = ?;
    SELECT @prd_codigo_out AS novo_codigo_produto;
"""
SQL_EXEC_PR_PRODUTO_U = """
    SET NOCOUNT ON;
    EXEC dbo.pr_produto_u
        @usu_codigo = ?, @sec_codigo = ?, @esp_codigo = ?, @prd_codigo = ?,
        @prd_descricao = ?, @prd_descricao_reduzida = ?, @mar_codigo = ?, @prd_data_cadastro = ?,
        @prd_unidade = ?, @prd_data_ultima_compra = ?, @prd_data_ultima_entrega = ?,
        @prd_custo_medio = ?, @prd_ultimo_custo = ?, @prd_preco_medio = ?, @prd_aliquota_icms = ?,
        @prd_codigo_original = ?, @prd_ativo = ?, @prd_arquivo_foto = ?, @prd_referencia_fornec = ?,
        @clf_codigo = ?, @usu_codigo_comprador = ?, @und_codigo = ?, @prd_valor_venda = ?,
        @prd_origem = ?, @prd_percentual_icms = ?, @prd_percentual_ipi = ?, @etq_codigo_padrao = ?,
        @prd_permite_comprar = ?, @udc_codigo = ?, @prd_valor_unidade_conversao = ?;
"""

# --- Constantes para PEDIDOS ---
PEDIDO_SHEET_NAME = "Cadastro de Pedidos"
PEDIDO_HEADER_ROW = 3
PEDIDO_DATA_START_ROW = 7
PEDIDO_COL_COD_ORIGINAL = 0
PEDIDO_COL_DT_ENTREGA_INICIAL = 3
PEDIDO_COL_DT_ENTREGA_FINAL = 4
PEDIDO_COL_OBSERVACAO = 8
PEDIDO_COL_FORNECEDOR = 702
PEDIDO_COL_COMPRADOR = 703
PEDIDO_COL_CONDICAO_PAG = 704
PEDIDO_COL_START_PAGAMENTOS = 707
PEDIDO_COL_QUALIDADE = 6
PEDIDO_COLS_PRODUTO_COD = range(11, 21)
PEDIDO_COLS_PRODUTO_CUSTO = range(21, 31)
PEDIDO_COL_JSON_GRADE_OFFSET = 20
PEDIDO_COL_START_FILIAIS = 41

# --- Constantes de SQL para PEDIDOS ---
SQL_GET_FILIAIS = "SELECT fil_codigo FROM tb_filial WITH(NOLOCK) ORDER BY fil_codigo;"
SQL_GET_VARIACOES_COM_ATRIBUTOS = """
    SELECT 
        ipr.ipr_codigo, 
        cor.aip_descricao AS cor, 
        tam.aip_descricao AS tamanho
    FROM tb_item_produto ipr WITH(NOLOCK)
    LEFT JOIN tb_atributo_item_produto cor WITH(NOLOCK) 
        ON ipr.sec_codigo = cor.sec_codigo AND ipr.esp_codigo = cor.esp_codigo AND ipr.prd_codigo = cor.prd_codigo AND ipr.ipr_codigo = cor.ipr_codigo AND cor.tpa_codigo = 1
    LEFT JOIN tb_atributo_item_produto tam WITH(NOLOCK) 
        ON ipr.sec_codigo = tam.sec_codigo AND ipr.esp_codigo = tam.esp_codigo AND ipr.prd_codigo = tam.prd_codigo AND ipr.ipr_codigo = tam.ipr_codigo AND tam.tpa_codigo = 2
    WHERE ipr.sec_codigo = ? AND ipr.esp_codigo = ? AND ipr.prd_codigo = ?;
"""
SQL_GET_PEDIDO_PARA_COMPARACAO = """
    SELECT pes_codigo, usu_codigo_comprador, ped_data_entrega_inicial, ped_data_entrega_final,
           ped_observacao, ped_codigo_original, ped_qualidade, cpg_codigo
    FROM tb_pedido WITH(NOLOCK)
    WHERE ped_codigo = ?;
"""
SQL_CLEAN_AUX_PEDIDO_PRODUTO = "DELETE FROM aux_pedido_produto WHERE usu_codigo = ?;"
SQL_CLEAN_AUX_ITEM_PEDIDO = "DELETE FROM aux_item_pedido WHERE usu_codigo = ?;"
SQL_CLEAN_AUX_TIPO_DOCUMENTO = "DELETE FROM aux_pedido_tipo_documento WHERE usu_codigo = ?;"
SQL_INSERT_AUX_PEDIDO_PRODUTO = "INSERT INTO aux_pedido_produto (usu_codigo, ped_codigo, sec_codigo, esp_codigo, prd_codigo, ppr_qtde_pedido, ppr_custo_medio) VALUES (?, ?, ?, ?, ?, ?, ?);"
SQL_INSERT_AUX_ITEM_PEDIDO = "INSERT INTO aux_item_pedido (usu_codigo, ped_codigo, sec_codigo, esp_codigo, prd_codigo, ipr_codigo, fil_codigo, ipd_pack, ipd_qtde_pedido, ipd_valor_custo, ipd_fator_grade, ipd_fator_filial, ipd_qtde_entregue) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0);"
SQL_INSERT_AUX_TIPO_DOCUMENTO = "INSERT INTO aux_pedido_tipo_documento (usu_codigo, ped_codigo, tid_codigo) VALUES (?, ?, ?);"
SQL_EXEC_PR_PEDIDO_I = """
    SET NOCOUNT ON;
    DECLARE @ped_codigo_out INT = ?;
    EXEC dbo.pr_pedido_i
        @usu_codigo = ?, @ped_codigo = @ped_codigo_out OUTPUT, @pes_codigo = ?,
        @usu_codigo_comprador = ?, @ped_data_emissao = ?, @ped_data_entrega_inicial = ?,
        @ped_data_entrega_final = ?, @ped_status = 'D', @ped_observacao = ?,
        @ped_qtde_total = ?, @ped_valor_total = ?, @ped_qtde_entregue_total = 0,
        @ped_custo_medio = ?, @ped_codigo_original = ?, @ped_qualidade = ?,
        @cpg_codigo = ?;
    SELECT @ped_codigo_out AS novo_codigo_pedido;
"""
SQL_EXEC_PR_PEDIDO_U = """
    SET NOCOUNT ON;
    EXEC dbo.pr_pedido_u
        @usu_codigo = ?, @ped_codigo = ?, @pes_codigo = ?,
        @usu_codigo_comprador = ?, @ped_data_emissao = ?, @ped_data_entrega_inicial = ?,
        @ped_data_entrega_final = ?, @ped_status = 'D', @ped_observacao = ?,
        @ped_qtde_total = ?, @ped_valor_total = ?, @ped_qtde_entregue_total = 0,
        @ped_custo_medio = ?, @ped_codigo_original = ?, @ped_qualidade = ?,
        @cpg_codigo = ?;
"""

# --- Data Classes ---
@dataclass
class Variacao:
    ipr_codigo: int; tpa_codigo: int; valor: str; ordem: int
    ipr_codigo_barra: Optional[str] = None

@dataclass
class Produto:
    linha_excel: int; secao: int; especie: int; prd_codigo: int; descricao: str
    descricao_reduzida: str; marca: int; referencia: str; data_cadastro: datetime
    cod_original: Optional[str] = None; comprador: Optional[int] = None
    und_codigo: Optional[int] = None; classificacao: Optional[int] = None
    origem: Optional[int] = None; etiqueta: Optional[int] = None
    venda: Optional[float] = None; icms: Optional[float] = None
    ipi: Optional[float] = None; ativo: int = 1
    prd_unidade: Optional[str] = None; prd_data_ultima_compra: Optional[datetime] = None
    prd_data_ultima_entrega: Optional[datetime] = None; prd_custo_medio: float = 0.0
    prd_preco_medio: float = 0.0; prd_aliquota_icms: float = 0.0
    prd_ultimo_custo: Optional[float] = None; prd_arquivo_foto: Optional[str] = None
    prd_permite_comprar: int = 1; prd_valor_unidade_conversao: Optional[float] = None
    udc_codigo: Optional[int] = None
    atributos_adicionais: List[Tuple[int, str]] = field(default_factory=list)
    variacoes: List[Variacao] = field(default_factory=list)
    log_alteracoes: List[str] = field(default_factory=list)

@dataclass
class ItemPedido:
    sec_codigo: int; esp_codigo: int; prd_codigo: int; custo: float
    fatores_filial: Dict[int, int]
    grade_detalhes: Dict[str, Any] = field(default_factory=dict)

@dataclass
class Pedido:
    linha_excel: int; ped_codigo: int; comprador: Optional[int]; dt_emissao: datetime
    fornecedor: Optional[str]
    dt_entrega_inicial: Optional[datetime]; dt_entrega_final: Optional[datetime]
    observacao: Optional[str]; cod_original: Optional[int]; qualidade: Optional[float]
    condicao_pagamento: int
    formas_pagamento: List[int] = field(default_factory=list)
    itens: List[ItemPedido] = field(default_factory=list)
    log_alteracoes: List[str] = field(default_factory=list)
    status_excel: Optional[str] = None

# --- Funções Utilitárias ---
def recurso_path(rel_path: str) -> str:
    try:
        base_path = sys._MEIPASS
    except AttributeError:
        base_path = os.path.abspath(".")
    return os.path.join(base_path, rel_path)

@contextmanager
def get_db_connection(commit_on_exit: bool = False):
    conn: Optional[pyodbc.Connection] = None
    try:
        with open(recurso_path(ARQUIVO_CONEXAO), 'r') as f:
            config = json.load(f)
        driver, server, database = config.get('driver'), config.get('server'), config.get('database')
        if config.get('trusted_connection', 'no').lower() == 'yes':
            conn_str = f"DRIVER={{{driver}}};SERVER={server};DATABASE={database};Trusted_Connection=yes;Encrypt=yes;TrustServerCertificate=yes"
        else:
            conn_str = f"DRIVER={{{driver}}};SERVER={server};DATABASE={database};UID={config.get('username')};PWD={config.get('password')};Encrypt=yes;TrustServerCertificate=yes"
        conn = pyodbc.connect(conn_str, autocommit=False)
        logger.debug("Conexão com o banco estabelecida.")
        yield conn
        if commit_on_exit and conn:
            conn.commit()
            logger.debug("Transação commitada com sucesso.")
    except Exception as e:
        if conn:
            conn.rollback()
            logger.error("Transação revertida (rollback) devido a erro.")
        logger.critical(f"ERRO de conexão/operação: {e}")
        raise
    finally:
        if conn:
            conn.close()
            logger.debug("Conexão com o banco fechada.")

def trata_valor(valor: Any, tipo_saida: type = int) -> Optional[Any]:
    if pd.isna(valor): return None
    valor_str = str(valor).strip()
    if not valor_str or valor_str.upper() in ['#N/D', '#N/A', 'N/D']: return None
    try:
        if tipo_saida == str: return valor_str
        valor_float = float(valor_str.replace(',', '.'))
        return int(valor_float) if tipo_saida == int else tipo_saida(valor_float)
    except (ValueError, TypeError):
        return None

# --- Funções de Produto ---
def _find_status_column_index(ws: openpyxl.worksheet.worksheet.Worksheet) -> Optional[int]:
    for col in range(1, ws.max_column + 1):
        cell_value = ws.cell(row=PRODUTO_HEADER_ROW, column=col).value
        if cell_value and str(cell_value).strip().lower() == 'status':
            return col - 1
    logger.error("Coluna 'Status' não encontrada na linha do cabeçalho (linha 3).")
    return None

def _get_colunas_adicionais(ws: openpyxl.worksheet.worksheet.Worksheet) -> List[str]:
    colunas = []
    idx_inicial = column_index_from_string(PRODUTO_COL_INICIAL_ADICIONAIS)
    idx_limite = column_index_from_string(PRODUTO_COL_LIMITE_ADICIONAIS)
    for current_col_idx in range(idx_inicial, idx_limite + 1):
        col_letter = get_column_letter(current_col_idx)
        valor = ws[f'{col_letter}{PRODUTO_HEADER_ROW}'].value
        if pd.isna(valor) or not valor: break
        colunas.append(col_letter)
    return colunas

def _get_tpa_codigos_map(cursor: pyodbc.Cursor, colunas_adicionais: List[str]) -> Dict[str, int]:
    cursor.execute(SQL_GET_TPA_CODIGOS)
    tpa_codes = [row.tpa_codigo for row in cursor.fetchall()]
    return {col_letter: tpa_code for col_letter, tpa_code in zip(colunas_adicionais, tpa_codes)}

def _valores_diferentes(valor_antigo: Any, valor_novo: Any) -> bool:
    if (pd.isna(valor_antigo) or valor_antigo is None) and \
       (pd.isna(valor_novo) or valor_novo is None):
        return False
    
    valor_antigo_norm = "" if valor_antigo is None or pd.isna(valor_antigo) else str(valor_antigo).strip()
    valor_novo_norm = "" if valor_novo is None or pd.isna(valor_novo) else str(valor_novo).strip()

    if isinstance(valor_antigo, datetime) and isinstance(valor_novo, datetime):
        if (valor_antigo.tzinfo is None) != (valor_novo.tzinfo is None):
            return valor_antigo.date() != valor_novo.date()
        return valor_antigo != valor_novo
    
    if isinstance(valor_antigo, datetime):
        try:
            return valor_antigo.date() != pd.to_datetime(valor_novo_norm).date()
        except (ValueError, TypeError):
            pass
    if isinstance(valor_novo, datetime):
        try:
            return valor_novo.date() != pd.to_datetime(valor_antigo_norm).date()
        except (ValueError, TypeError):
            pass

    try:
        if float(valor_antigo_norm) != float(valor_novo_norm):
            return True
    except (ValueError, TypeError):
        if valor_antigo_norm != valor_novo_norm:
            return True
            
    return False

def _registrar_diferencas_conjunto(log_list: List[str], nome_campo: str, conjunto_antigo: set, conjunto_novo: set):
    adicionados = conjunto_novo - conjunto_antigo
    removidos = conjunto_antigo - conjunto_novo
    if adicionados:
        log_list.append(f"   - {nome_campo} (Adicionados): {', '.join(map(repr, sorted(list(adicionados))))}")
    if removidos:
        log_list.append(f"   - {nome_campo} (Removidos): {', '.join(map(repr, sorted(list(removidos))))}")

def _limpar_tabelas_auxiliares(cursor: pyodbc.Cursor, usu_codigo_logado: int):
    logger.debug(f"Limpando tabelas auxiliares para o usuário {usu_codigo_logado}.")
    cursor.execute(SQL_CLEAN_AUX_ITEM, usu_codigo_logado)
    cursor.execute(SQL_CLEAN_AUX_ATTR_ITEM, usu_codigo_logado)
    cursor.execute(SQL_CLEAN_AUX_ATTR_PROD, usu_codigo_logado)

def _preencher_tabelas_auxiliares(cursor: pyodbc.Cursor, produto: Produto, usu_codigo_logado: int):
    params_aux_item, params_aux_atr_item = [], []
    ipr_counter = 1
    cores = [v for v in produto.variacoes if v.tpa_codigo == 1]
    tamanhos = [v for v in produto.variacoes if v.tpa_codigo == 2]
    if cores and tamanhos:
        for cor in cores:
            for tamanho in tamanhos:
                params_aux_item.append((usu_codigo_logado, ipr_counter, None, 0, produto.secao, produto.especie, produto.prd_codigo))
                params_aux_atr_item.append((usu_codigo_logado, ipr_counter, 1, cor.valor, cor.ordem))
                params_aux_atr_item.append((usu_codigo_logado, ipr_counter, 2, tamanho.valor, tamanho.ordem))
                ipr_counter += 1
    elif cores or tamanhos:
        variacoes_simples = cores if cores else tamanhos
        for variacao in variacoes_simples:
            params_aux_item.append((usu_codigo_logado, ipr_counter, None, 0, produto.secao, produto.especie, produto.prd_codigo))
            params_aux_atr_item.append((usu_codigo_logado, ipr_counter, variacao.tpa_codigo, variacao.valor, variacao.ordem))
            ipr_counter += 1
    else:
        params_aux_item.append((usu_codigo_logado, 1, None, 0, produto.secao, produto.especie, produto.prd_codigo))
    
    if params_aux_item: cursor.executemany(SQL_INSERT_AUX_ITEM_PRODUTO, params_aux_item)
    if params_aux_atr_item: cursor.executemany(SQL_INSERT_AUX_ATRIBUTO_ITEM, params_aux_atr_item)
    
    params_aux_atr_prod = [(usu_codigo_logado, tpa, desc) for tpa, desc in produto.atributos_adicionais]
    if params_aux_atr_prod: cursor.executemany(SQL_INSERT_AUX_ATRIBUTO_PRODUTO, params_aux_atr_prod)
    
    logger.debug(f"Tabelas auxiliares populadas para o produto da linha {produto.linha_excel}.")

def _processar_produto_com_sp(cursor: pyodbc.Cursor, produto: Produto, usu_codigo_logado: int) -> Optional[int]:
    try:
        _limpar_tabelas_auxiliares(cursor, usu_codigo_logado)
        _preencher_tabelas_auxiliares(cursor, produto, usu_codigo_logado)
        params_sp = [
            usu_codigo_logado, produto.secao, produto.especie,
            produto.descricao, produto.descricao_reduzida, produto.marca, produto.data_cadastro,
            None, None, None, 0, 0, 0, 0,
            produto.cod_original, 1, None, produto.referencia,
            produto.classificacao, produto.comprador, produto.und_codigo, produto.venda,
            produto.origem, produto.icms, produto.ipi, produto.etiqueta,
            produto.prd_permite_comprar, produto.udc_codigo, produto.prd_valor_unidade_conversao
        ]
        logger.debug(f"Executando pr_produto_i para o produto da linha {produto.linha_excel}.")
        cursor.execute(SQL_EXEC_PR_PRODUTO_I, params_sp)
        result = cursor.fetchone()
        novo_codigo = result.novo_codigo_produto if result else None
        if not novo_codigo:
            raise Exception(f"A SP de Inclusão não retornou um novo código para o produto da linha {produto.linha_excel}.")
        return novo_codigo
    except pyodbc.Error as ex:
        sqlstate = ex.args[0]
        if sqlstate == '42000':
            produto.log_alteracoes.append(f"ERRO INSERÇÃO: {str(ex)}")
        else:
            produto.log_alteracoes.append(f"ERRO DB INSERÇÃO: {str(ex)}")
        logger.error(f"Erro ao processar INCLUSÃO da linha {produto.linha_excel}: {ex}")
        return None
    except Exception as e:
        produto.log_alteracoes.append(f"ERRO SCRIPT INSERÇÃO: {str(e)}")
        logger.error(f"Erro no script Python ao processar INCLUSÃO da linha {produto.linha_excel}: {e}")
        return None

def _processar_produto_update_com_sp(cursor: pyodbc.Cursor, produto_novo: Produto, usu_codigo_logado: int) -> bool:
    try:
        logger.debug(f"Comparando dados para o produto da linha {produto_novo.linha_excel}")
        cursor.execute(SQL_GET_PRODUTO_PARA_COMPARACAO, produto_novo.secao, produto_novo.especie, produto_novo.prd_codigo)
        produto_antigo = cursor.fetchone()
        if not produto_antigo:
            produto_novo.log_alteracoes.append("ERRO: Produto não encontrado no banco de dados para alteração.")
            return False
            
        campos_a_comparar = {
            'prd_descricao': ('descricao', 'Descrição'), 'prd_descricao_reduzida': ('descricao_reduzida', 'Desc. Reduzida'),
            'mar_codigo': ('marca', 'Marca'), 'prd_referencia_fornec': ('referencia', 'Referência'),
            'prd_codigo_original': ('cod_original', 'Cód. Original'), 'usu_codigo_comprador': ('comprador', 'Comprador'),
            'und_codigo': ('und_codigo', 'Unidade'), 'clf_codigo': ('classificacao', 'Classif. Fiscal'),
            'prd_origem': ('origem', 'Origem'), 'etq_codigo_padrao': ('etiqueta', 'Etiqueta'),
            'prd_valor_venda': ('venda', 'Preço Venda'), 'prd_aliquota_icms': ('icms', 'ICMS (%)'),
            'prd_percentual_ipi': ('ipi', 'IPI (%)'),
        }
        for db_col, (attr_novo, nome_campo) in campos_a_comparar.items():
            valor_antigo = getattr(produto_antigo, db_col)
            valor_novo = getattr(produto_novo, attr_novo)
            if _valores_diferentes(valor_antigo, valor_novo):
                produto_novo.log_alteracoes.append(f"   - {nome_campo}: de '{valor_antigo or 'N/A'}' para '{valor_novo or 'N/A'}'")

        cursor.execute(SQL_GET_ATRIBUTOS_ITEM_PRODUTO, produto_novo.secao, produto_novo.especie, produto_novo.prd_codigo)
        db_variacoes = cursor.fetchall()
        cores_antigas = {v.aip_descricao for v in db_variacoes if v.tpa_codigo == 1 and v.aip_descricao}
        tamanhos_antigos = {v.aip_descricao for v in db_variacoes if v.tpa_codigo == 2 and v.aip_descricao}
        cores_novas = {v.valor for v in produto_novo.variacoes if v.tpa_codigo == 1 and v.valor}
        tamanhos_novos = {v.valor for v in produto_novo.variacoes if v.tpa_codigo == 2 and v.valor}
        _registrar_diferencas_conjunto(produto_novo.log_alteracoes, "Cores", cores_antigas, cores_novas)
        _registrar_diferencas_conjunto(produto_novo.log_alteracoes, "Tamanhos", tamanhos_antigos, tamanhos_novos)
        
        cursor.execute(SQL_GET_ATRIBUTOS_PRODUTO, produto_novo.secao, produto_novo.especie, produto_novo.prd_codigo)
        atributos_antigos = {f"{a.tpa_codigo}:{a.apr_descricao}" for a in cursor.fetchall() if a.apr_descricao}
        atributos_novos = {f"{tpa}:{desc}" for tpa, desc in produto_novo.atributos_adicionais if desc}
        _registrar_diferencas_conjunto(produto_novo.log_alteracoes, "Atributos Adicionais", atributos_antigos, atributos_novos)

        _limpar_tabelas_auxiliares(cursor, usu_codigo_logado)
        _preencher_tabelas_auxiliares(cursor, produto_novo, usu_codigo_logado)
        
        params_sp = [
            usu_codigo_logado, produto_novo.secao, produto_novo.especie, produto_novo.prd_codigo,
            produto_novo.descricao, produto_novo.descricao_reduzida, produto_novo.marca, produto_novo.data_cadastro,
            produto_novo.prd_unidade, produto_novo.prd_data_ultima_compra, produto_novo.prd_data_ultima_entrega,
            produto_novo.prd_custo_medio, produto_novo.prd_ultimo_custo, produto_novo.prd_preco_medio, produto_novo.prd_aliquota_icms,
            produto_novo.cod_original, produto_novo.ativo, produto_novo.prd_arquivo_foto, produto_novo.referencia,
            produto_novo.classificacao, produto_novo.comprador, produto_novo.und_codigo, produto_novo.venda,
            produto_novo.origem, produto_novo.icms, produto_novo.ipi, produto_novo.etiqueta,
            produto_novo.prd_permite_comprar, produto_novo.udc_codigo, produto_novo.prd_valor_unidade_conversao
        ]
        logger.debug(f"Executando pr_produto_u para o produto {produto_novo.secao}-{produto_novo.especie}-{produto_novo.prd_codigo}.")
        cursor.execute(SQL_EXEC_PR_PRODUTO_U, params_sp)
        return True
    except pyodbc.Error as ex:
        sqlstate = ex.args[0]
        if sqlstate == '42000':
            produto_novo.log_alteracoes.append(f"ERRO ALTERAÇÃO: {str(ex)}")
        else:
            produto_novo.log_alteracoes.append(f"ERRO DB ALTERAÇÃO: {str(ex)}")
        logger.error(f"Erro ao processar ALTERAÇÃO da linha {produto_novo.linha_excel}: {ex}")
        return False
    except Exception as e:
        produto_novo.log_alteracoes.append(f"ERRO SCRIPT ALTERAÇÃO: {str(e)}")
        logger.error(f"Erro no script Python ao processar ALTERAÇÃO da linha {produto_novo.linha_excel}: {e}")
        return False

def cadastrar_produto(excel_path: str, usu_codigo_logado: int) -> List[str]:
    start_total = time.time()
    logs = []
    if not excel_path:
        logs.append("ERRO: O caminho do arquivo Excel não foi fornecido.")
        return logs
    
    wb = None
    all_products_processed = []
    try:
        wb = openpyxl.load_workbook(excel_path, data_only=True, read_only=True)
        ws = wb[PRODUTO_SHEET_NAME]
        df = pd.read_excel(excel_path, sheet_name=PRODUTO_SHEET_NAME, skiprows=PRODUTO_DATA_START_ROW - 1, header=None, dtype=str).dropna(how='all')
        
        status_col_idx = _find_status_column_index(ws)
        if status_col_idx is None:
            raise ValueError("Coluna 'Status' não encontrada.")
            
        produtos_para_inserir, produtos_para_atualizar = [], []
        with get_db_connection() as conn:
            cursor = conn.cursor()
            col_adicionais = _get_colunas_adicionais(ws)
            tpa_map = _get_tpa_codigos_map(cursor, col_adicionais)
            for i, row in df.iterrows():
                linha_excel = i + PRODUTO_DATA_START_ROW
                status_value = trata_valor(row.iloc[status_col_idx], str)
                is_update = bool(status_value and status_value.isdigit() and len(status_value) == 9)
                cores = [str(ws[f'{c}{linha_excel}'].value).strip() for c in PRODUTO_COLS_CORES if pd.notna(ws[f'{c}{linha_excel}'].value)]
                tamanhos = [str(ws[f'{t}{linha_excel}'].value).strip() for t in PRODUTO_COLS_TAMANHOS if pd.notna(ws[f'{t}{linha_excel}'].value)]
                variacoes = []
                for ordem, cor in enumerate(cores, 1): variacoes.append(Variacao(ipr_codigo=0, tpa_codigo=1, valor=cor, ordem=ordem))
                for ordem, tamanho in enumerate(tamanhos, 1): variacoes.append(Variacao(ipr_codigo=0, tpa_codigo=2, valor=tamanho, ordem=ordem))
                atributos = [(tpa_map[col], str(ws[f"{col}{linha_excel}"].value)) for col in col_adicionais if pd.notna(ws[f"{col}{linha_excel}"].value) and col in tpa_map]
                ref_raw = row.iloc[5]
                referencia = str(int(ref_raw)) if isinstance(ref_raw, float) and ref_raw.is_integer() else str(ref_raw) if pd.notna(ref_raw) else None
                produto_data = {
                    "linha_excel": linha_excel, "descricao": str(row.iloc[2])[:50],
                    "descricao_reduzida": str(row.iloc[3])[:50], "marca": trata_valor(row.iloc[86], int),
                    "referencia": referencia, "cod_original": str(row.iloc[6]) if pd.notna(row.iloc[6]) else None,
                    "comprador": trata_valor(row.iloc[87], int), "und_codigo": trata_valor(row.iloc[88], int),
                    "classificacao": trata_valor(row.iloc[89], int), "origem": trata_valor(row.iloc[90], int),
                    "etiqueta": trata_valor(row.iloc[91], int), "venda": trata_valor(row.iloc[12], float),
                    "icms": trata_valor(row.iloc[13], float), "ipi": trata_valor(row.iloc[14], float),
                    "variacoes": variacoes, "atributos_adicionais": atributos, "data_cadastro": datetime.now()
                }
                if is_update:
                    try:
                        secao, especie, prd_codigo = int(status_value[0:3]), int(status_value[3:5]), int(status_value[5:9])
                        produto_obj = Produto(secao=secao, especie=especie, prd_codigo=prd_codigo, **produto_data)
                        produtos_para_atualizar.append(produto_obj)
                    except (ValueError, IndexError):
                        logger.error(f"Linha {linha_excel}: Código '{status_value}' inválido para atualização.")
                else:
                    secao, especie = trata_valor(row.iloc[84], int), trata_valor(row.iloc[85], int)
                    if not secao or not especie:
                        continue
                    produto_obj = Produto(secao=secao, especie=especie, prd_codigo=0, **produto_data)
                    produtos_para_inserir.append(produto_obj)

        if not produtos_para_inserir and not produtos_para_atualizar:
            return []

        logs.append(f"Iniciando cadastro/alteração de produtos (via SP) do arquivo: {os.path.basename(excel_path)}")
        all_products_processed = produtos_para_inserir + produtos_para_atualizar
        produtos_inseridos_count, produtos_atualizados_count, produtos_com_erro = 0, 0, 0
        
        with get_db_connection(commit_on_exit=False) as conn:
            cursor = conn.cursor()
            for produto in produtos_para_inserir:
                if _processar_produto_com_sp(cursor, produto, usu_codigo_logado):
                    produtos_inseridos_count += 1
                else:
                    produtos_com_erro += 1
            for produto in produtos_para_atualizar:
                if _processar_produto_update_com_sp(cursor, produto, usu_codigo_logado):
                    produtos_atualizados_count += 1
                else:
                    produtos_com_erro += 1
            
            if produtos_com_erro == 0 and (produtos_inseridos_count > 0 or produtos_atualizados_count > 0):
                conn.commit()
                logger.info("Operações concluídas com sucesso. Transação commitada.")
            else:
                conn.rollback()
                if produtos_com_erro > 0:
                    logger.error(f"{produtos_com_erro} produtos falharam. Transação revertida (rollback).")
                    logs.append(f"\nATENÇÃO: {produtos_com_erro} produto(s) continha(m) erros. NENHUMA operação foi salva.")
                    
        logs.insert(0, "\n--- Relatório do Cadastro de Produtos (via Stored Procedure) ---")
        logs.insert(1, f"Planilha: {len(produtos_para_inserir)} produtos para INSERIR | {len(produtos_para_atualizar)} para ALTERAR.")
        logs.insert(2, f"--> SUCESSO: {produtos_inseridos_count} inseridos, {produtos_atualizados_count} alterados.")
        logs.insert(3, f"--> FALHA: {produtos_com_erro} produtos.")
        logs.append("-" * 40)
        logs.append("Detalhes das Operações:")
        for p in all_products_processed:
            cod_str = f"{p.secao:03}{p.especie:02}{p.prd_codigo:04}" if p.prd_codigo else "NOVO"
            header = f"-> Produto {cod_str} (Linha Excel: {p.linha_excel}):"
            if p.log_alteracoes:
                if "ERRO" in p.log_alteracoes[0]:
                    logs.append(f"{header} FALHA")
                    logs.append(f"   {p.log_alteracoes[0]}")
                else:
                    logs.append(f"{header} ALTERADO COM SUCESSO")
                    logs.extend(p.log_alteracoes)
            else:
                if p.prd_codigo != 0:
                    logs.append(f"{header} Nenhuma alteração de dados detectada.")
                else:
                    logs.append(f"{header} INSERIDO COM SUCESSO.")
    except Exception as e:
        error_message = f"ERRO CRÍTICO em cadastrar_produto: {e}"
        logger.critical(error_message, exc_info=True)
        if not any("Relatório" in log for log in logs):
             logs.insert(0, "\n--- Relatório do Cadastro de Produtos (via Stored Procedure) ---")
        logs.append(error_message)
    finally:
        if wb: wb.close()
        if logs:
            elapsed_time = f"Tempo total de execução (Produtos): {time.time() - start_total:.2f}s"
            logs.append(elapsed_time)
            logger.info(elapsed_time)
        return logs

# --- LÓGICA DE CADASTRO E ATUALIZAÇÃO DE PEDIDO ---
def _parse_grade_json_detalhada(json_string: Optional[str]) -> Dict[str, Any]:
    grade_map = {}
    if not json_string or pd.isna(json_string):
        return grade_map
    try:
        data = json.loads(json_string)
        detalhes = data.get('detalhes', [])
        if not (detalhes and isinstance(detalhes, list)):
            return grade_map
        for item in detalhes:
            cor = item.get('cor')
            tamanho = item.get('tamanho')
            qtde = item.get('qtde')
            multiplicador = item.get('multiplicador')
            if cor is None or tamanho is None or qtde is None or multiplicador is None:
                continue
            if cor not in grade_map:
                grade_map[cor] = {'multiplicador': int(multiplicador), 'tamanhos': {}}
            grade_map[cor]['tamanhos'][tamanho] = int(qtde)
            grade_map[cor]['multiplicador'] = int(multiplicador)
    except (json.JSONDecodeError, ValueError, TypeError) as e:
        logger.warning(f"Não foi possível analisar o JSON da grade: '{str(json_string)[:100]}...'. Erro: {e}. Grade será ignorada.")
        return {}
    return grade_map

def _prepare_pedidos_from_excel(data_list: list, filiais: List[int], status_col_idx: int) -> List[Pedido]:
    pedidos = []
    for i, row in enumerate(data_list):
        linha_excel = i + PEDIDO_DATA_START_ROW
        status_value = trata_valor(row[status_col_idx], str)
        ped_codigo = 0
        is_update = False
        status_pedido_excel = None
        try:
            if status_value is not None:
                ped_codigo = int(float(status_value))
                is_update = True
        except (ValueError, TypeError):
            if status_value != "Pronto para sincronizacao...":
                logger.info(f"Linha {linha_excel} ignorada: Status '{status_value}' inválido para importação/atualização.")
                continue
            is_update = False
        
        if is_update:
            try:
                status_pedido_excel = str(row[status_col_idx + 1]).strip()
                if status_pedido_excel != 'D':
                    logger.error(f"Linha {linha_excel}: Pedido {ped_codigo} não pode ser atualizado. Status '{status_pedido_excel}' (Esperado: 'D').")
                    pedido_erro = Pedido(linha_excel=linha_excel, ped_codigo=ped_codigo, comprador=None, dt_emissao=datetime.now(), fornecedor=None, dt_entrega_inicial=None, dt_entrega_final=None, observacao=None, cod_original=None, qualidade=None, condicao_pagamento=1, status_excel=status_pedido_excel)
                    pedido_erro.log_alteracoes.append(f"ERRO UPDATE: Status do pedido na planilha é '{status_pedido_excel}'. Só é permitido atualizar pedidos com status 'D' (Digitando).")
                    pedidos.append(pedido_erro)
                    continue
            except IndexError:
                logger.error(f"Linha {linha_excel}: Não foi possível verificar o status (coluna após 'Status') do pedido {ped_codigo}.")
                continue
                
        fornecedor_id = trata_valor(row[PEDIDO_COL_FORNECEDOR], str)
        if not fornecedor_id:
            continue
            
        itens_pedido = []
        for j, col_idx in enumerate(PEDIDO_COLS_PRODUTO_COD):
            cod_produto_completo = trata_valor(row[col_idx], str)
            if not cod_produto_completo: continue
            try:
                col_json_idx = col_idx + PEDIDO_COL_JSON_GRADE_OFFSET
                json_grade_raw = row[col_json_idx] if col_json_idx < len(row) else None
                grade_detalhes = _parse_grade_json_detalhada(json_grade_raw)
                logger.debug(f"Linha {linha_excel} | Cód. Produto: {cod_produto_completo} | Grade Detalhada: {grade_detalhes}")
                if '.' in cod_produto_completo: cod_produto_completo = cod_produto_completo.split('.')[0]
                cod_produto_completo = cod_produto_completo.zfill(9)
                sec_codigo, esp_codigo, prd_codigo = int(cod_produto_completo[:3]), int(cod_produto_completo[3:5]), int(cod_produto_completo[5:9])
                fatores_filial = {}
                col_fator_start = PEDIDO_COL_START_FILIAIS + (j * len(filiais))
                for k, fil_codigo in enumerate(filiais):
                    fator_float = trata_valor(row[col_fator_start + k], float)
                    if fator_float and fator_float > 0: fatores_filial[fil_codigo] = int(fator_float)
                if fatores_filial:
                    itens_pedido.append(ItemPedido(sec_codigo=sec_codigo, esp_codigo=esp_codigo, prd_codigo=prd_codigo, custo=trata_valor(row[PEDIDO_COLS_PRODUTO_CUSTO[j]], float) or 0.0, fatores_filial=fatores_filial, grade_detalhes=grade_detalhes))
            except (ValueError, IndexError, TypeError) as e:
                logger.warning(f"AVISO: Erro ao processar item na linha {linha_excel}, produto {j+1} (Cód: {cod_produto_completo}). Erro: {e}")
                continue
                
        if not itens_pedido:
            if is_update or (status_value == "Pronto para sincronizacao..."):
                logger.warning(f"Linha {linha_excel} ignorada: Nenhum item válido encontrado para o pedido.")
            continue
            
        formas_pagamento = [val for k in range(PEDIDO_COL_START_PAGAMENTOS, len(row)) if (val := trata_valor(row[k], int))]
        pedidos.append(Pedido(
            linha_excel=linha_excel, ped_codigo=ped_codigo, fornecedor=fornecedor_id,
            comprador=trata_valor(row[PEDIDO_COL_COMPRADOR], int), dt_emissao=datetime.now(), 
            dt_entrega_inicial=pd.to_datetime(row[PEDIDO_COL_DT_ENTREGA_INICIAL], errors='coerce'), 
            dt_entrega_final=pd.to_datetime(row[PEDIDO_COL_DT_ENTREGA_FINAL], errors='coerce'), 
            observacao=str(row[PEDIDO_COL_OBSERVACAO]) if pd.notna(row[PEDIDO_COL_OBSERVACAO]) else None, 
            cod_original=trata_valor(row[PEDIDO_COL_COD_ORIGINAL], int), 
            qualidade=trata_valor(row[PEDIDO_COL_QUALIDADE], float), 
            condicao_pagamento=trata_valor(row[PEDIDO_COL_CONDICAO_PAG], int) or 1, 
            formas_pagamento=formas_pagamento, itens=itens_pedido,
            status_excel=status_pedido_excel
        ))
    return pedidos

def _processar_pedido_sp(cursor: pyodbc.Cursor, pedido_novo: Pedido, cache_variacoes: dict, usu_codigo_logado: int) -> bool:
    if pedido_novo.log_alteracoes and any("ERRO UPDATE" in log for log in pedido_novo.log_alteracoes):
        return False

    is_update = pedido_novo.ped_codigo > 0

    try:
        if is_update:
            logger.debug(f"Comparando dados para o pedido da linha {pedido_novo.linha_excel}")
            cursor.execute(SQL_GET_PEDIDO_PARA_COMPARACAO, pedido_novo.ped_codigo)
            pedido_antigo = cursor.fetchone()
            if not pedido_antigo:
                pedido_novo.log_alteracoes.append("ERRO: Pedido não encontrado no banco de dados para alteração.")
                return False
            
            campos_a_comparar_pedido = {
                'pes_codigo': ('fornecedor', 'Fornecedor', 'AAA'),
                'usu_codigo_comprador': ('comprador', 'Comprador', 'AAB'),
                'ped_data_entrega_inicial': ('dt_entrega_inicial', 'Data Entrega Inicial', 'D'),
                'ped_data_entrega_final': ('dt_entrega_final', 'Data Entrega Final', 'E'),
                'ped_observacao': ('observacao', 'Observação', 'I'),
                'ped_codigo_original': ('cod_original', 'Cód. Original', 'A'),
                'ped_qualidade': ('qualidade', 'Qualidade', 'G'),
                'cpg_codigo': ('condicao_pagamento', 'Cond. Pagamento', 'AAC')
            }
            
            for db_col, (attr_novo, nome_campo, col_excel) in campos_a_comparar_pedido.items():
                valor_antigo = getattr(pedido_antigo, db_col)
                valor_novo = getattr(pedido_novo, attr_novo)
                if _valores_diferentes(valor_antigo, valor_novo):
                    pedido_novo.log_alteracoes.append(f"   - {nome_campo} (Coluna {col_excel}): de '{valor_antigo or 'N/A'}' para '{valor_novo or 'N/A'}'")
        
        cursor.execute(SQL_CLEAN_AUX_PEDIDO_PRODUTO, usu_codigo_logado)
        cursor.execute(SQL_CLEAN_AUX_ITEM_PEDIDO, usu_codigo_logado)
        cursor.execute(SQL_CLEAN_AUX_TIPO_DOCUMENTO, usu_codigo_logado)
        
        params_aux_item_ped, params_aux_ped_prod = [], []
        itens_unicos = {}
        ped_codigo_aux = pedido_novo.ped_codigo if is_update else 0

        for item in pedido_novo.itens:
            chave_produto = (item.sec_codigo, item.esp_codigo, item.prd_codigo)
            if chave_produto not in itens_unicos:
                itens_unicos[chave_produto] = {'custo': item.custo, 'qtde_total': 0}
            if chave_produto not in cache_variacoes:
                cursor.execute(SQL_GET_VARIACOES_COM_ATRIBUTOS, chave_produto)
                cache_variacoes[chave_produto] = cursor.fetchall()
            variacoes_do_produto = cache_variacoes[chave_produto]
            if not variacoes_do_produto:
                logger.warning(f"Pedido da linha {pedido_novo.linha_excel}: Produto {chave_produto} não possui variações e será ignorado.")
                continue
            for variacao in variacoes_do_produto:
                cor_db = variacao.cor or ''
                tamanho_db = variacao.tamanho or ''
                dados_cor_json = item.grade_detalhes.get(cor_db, {})
                qtde_json = dados_cor_json.get('tamanhos', {}).get(tamanho_db, 0)
                multiplicador_json = dados_cor_json.get('multiplicador', 1)
                if qtde_json > 0:
                    for fil_codigo, fator_filial in item.fatores_filial.items():
                        qtde_final_pedido = qtde_json * fator_filial * multiplicador_json
                        params_aux_item_ped.append((
                            usu_codigo_logado, ped_codigo_aux,
                            item.sec_codigo, item.esp_codigo, item.prd_codigo, variacao.ipr_codigo,
                            fil_codigo, 1, qtde_final_pedido, item.custo, 
                            multiplicador_json, fator_filial
                        ))
                        itens_unicos[chave_produto]['qtde_total'] += qtde_final_pedido
        
        for (sec, esp, prd), dados in itens_unicos.items():
            params_aux_ped_prod.append((usu_codigo_logado, ped_codigo_aux, sec, esp, prd, dados['qtde_total'], dados['custo']))
        params_aux_tipo_doc = [(usu_codigo_logado, ped_codigo_aux, tid) for tid in pedido_novo.formas_pagamento]

        if params_aux_ped_prod: cursor.executemany(SQL_INSERT_AUX_PEDIDO_PRODUTO, params_aux_ped_prod)
        if params_aux_item_ped: cursor.executemany(SQL_INSERT_AUX_ITEM_PEDIDO, params_aux_item_ped)
        if params_aux_tipo_doc: cursor.executemany(SQL_INSERT_AUX_TIPO_DOCUMENTO, params_aux_tipo_doc)
        
        ped_qtde_total = sum(dados['qtde_total'] for dados in itens_unicos.values())
        ped_valor_total = sum(dados['custo'] * dados['qtde_total'] for dados in itens_unicos.values())
        ped_custo_medio = ped_valor_total / ped_qtde_total if ped_qtde_total > 0 else 0

        if is_update:
            params_sp = (
                usu_codigo_logado, pedido_novo.ped_codigo, pedido_novo.fornecedor, pedido_novo.comprador,
                pedido_novo.dt_emissao, pedido_novo.dt_entrega_inicial, pedido_novo.dt_entrega_final,
                pedido_novo.observacao, ped_qtde_total, ped_valor_total,
                ped_custo_medio, pedido_novo.cod_original, pedido_novo.qualidade, pedido_novo.condicao_pagamento
            )
            sql_exec = SQL_EXEC_PR_PEDIDO_U
            log_action = "pr_pedido_u"
        else:
            params_sp = (
                0, usu_codigo_logado, pedido_novo.fornecedor, pedido_novo.comprador,
                pedido_novo.dt_emissao, pedido_novo.dt_entrega_inicial, pedido_novo.dt_entrega_final,
                pedido_novo.observacao, ped_qtde_total, ped_valor_total,
                ped_custo_medio, pedido_novo.cod_original, pedido_novo.qualidade, pedido_novo.condicao_pagamento
            )
            sql_exec = SQL_EXEC_PR_PEDIDO_I
            log_action = "pr_pedido_i"
        
        logger.debug(f"Executando {log_action} para pedido da linha Excel {pedido_novo.linha_excel} (Cód: {pedido_novo.ped_codigo})")
        cursor.execute(sql_exec, params_sp)
        
        if not is_update:
            novo_codigo = cursor.fetchone()
            if not novo_codigo or not novo_codigo[0]:
                error_msg = f"A SP pr_pedido_i não retornou um novo código para o pedido da linha {pedido_novo.linha_excel}."
                logger.error(error_msg)
                pedido_novo.log_alteracoes.append(f"ERRO INSERT: {error_msg}")
                return False
            pedido_novo.ped_codigo = novo_codigo[0]
            logger.info(f"Pedido da linha {pedido_novo.linha_excel} inserido com sucesso. Novo Código: {pedido_novo.ped_codigo}")
        
        return True

    except Exception as e:
        logger.error(f"Erro ao processar pedido da linha {pedido_novo.linha_excel} (Cód: {pedido_novo.ped_codigo}) com SP: {e}", exc_info=True)
        pedido_novo.log_alteracoes.append(f"ERRO DB: {e}")
        return False

def cadastrar_pedido(excel_path: str, usu_codigo_logado: int) -> List[str]:
    start_total = time.time()
    logs = []
    if not excel_path:
        logs.append("ERRO: O caminho do arquivo Excel não foi fornecido.")
        return logs
    try:
        df_header = pd.read_excel(excel_path, sheet_name=PEDIDO_SHEET_NAME, skiprows=PEDIDO_HEADER_ROW - 1, nrows=1, header=None)
        status_col_idx = -1
        for idx, value in df_header.iloc[0].items():
            if str(value).strip().lower() == 'status':
                status_col_idx = idx
                break
        if status_col_idx == -1:
            raise ValueError("Coluna 'Status' não encontrada na linha 3 da aba 'Cadastro de Pedidos'.")
        
        df_rows = pd.read_excel(excel_path, sheet_name=PEDIDO_SHEET_NAME, skiprows=PEDIDO_DATA_START_ROW - 1, header=None).dropna(how='all')

        with get_db_connection(commit_on_exit=False) as conn:
            cursor = conn.cursor()
            filiais = [row.fil_codigo for row in cursor.execute(SQL_GET_FILIAIS).fetchall()]
            data_list = df_rows.values.tolist() if not df_rows.empty else []
            pedidos_a_processar = _prepare_pedidos_from_excel(data_list, filiais, status_col_idx)

            if not pedidos_a_processar:
                return []

            logs.append(f"\nIniciando cadastro/atualização de pedidos (via SP) do arquivo: {os.path.basename(excel_path)}")
            pedidos_inserir = [p for p in pedidos_a_processar if p.ped_codigo == 0 and not p.log_alteracoes]
            pedidos_atualizar = [p for p in pedidos_a_processar if p.ped_codigo > 0]
            pedidos_com_erro_prep = [p for p in pedidos_a_processar if p.ped_codigo > 0 and p.log_alteracoes and "ERRO" in p.log_alteracoes[0]]
            
            logger.info(f"Total de pedidos preparados: {len(pedidos_inserir)} para INSERIR, {len(pedidos_atualizar)} para ATUALIZAR, {len(pedidos_com_erro_prep)} com erros de validação.")
            
            pedidos_sucesso_count = 0
            pedidos_com_erro = len(pedidos_com_erro_prep)
            cache_variacoes_produto = {}
            
            for pedido in [p for p in pedidos_a_processar if p not in pedidos_com_erro_prep]:
                if _processar_pedido_sp(cursor, pedido, cache_variacoes_produto, usu_codigo_logado):
                    pedidos_sucesso_count += 1
                else:
                    pedidos_com_erro += 1
                    
            if pedidos_com_erro == 0 and pedidos_sucesso_count > 0:
                conn.commit()
                logger.info(f"SUCESSO: {pedidos_sucesso_count} pedidos processados (I/U). Transação commitada.")
            else:
                conn.rollback()
                if pedidos_com_erro > 0:
                    logger.error(f"FALHA: {pedidos_com_erro} pedido(s) apresentou(aram) erro. Nenhuma alteração foi salva (Rollback).")
                    if any(p for p in pedidos_a_processar if not p.log_alteracoes):
                        logs.append(f"\nATENÇÃO: {pedidos_com_erro} pedido(s) continha(m) erros. NENHUMA operação de pedido foi salva.")
                        
        logs.append("\n--- Relatório do Cadastro/Atualização de Pedidos ---")
        logs.append(f"Planilha: {len(pedidos_inserir)} para INSERIR | {len(pedidos_atualizar)} para ATUALIZAR.")
        logs.append(f"--> Processados com Sucesso: {pedidos_sucesso_count}")
        logs.append(f"--> Pedidos com Falha: {pedidos_com_erro}")
        logs.append("-" * 40)
        logs.append("Detalhes das Operações de Pedido:")
        for p in pedidos_a_processar:
            tipo_op = "NOVO"
            if p.ped_codigo > 0:
                tipo_op = f"Cód: {p.ped_codigo}"
            header = f"-> Pedido (Linha Excel: {p.linha_excel}, {tipo_op}):"
            if p.log_alteracoes:
                if "ERRO" in p.log_alteracoes[0]:
                    logs.append(f"{header} FALHA")
                else:
                    logs.append(f"{header} ALTERADO COM SUCESSO")
                logs.extend(p.log_alteracoes)
            else:
                if p.ped_codigo > 0:
                    logs.append(f"{header} Nenhuma alteração de dados detectada.")
                else:
                    logs.append(f"{header} INSERIDO COM SUCESSO.")
    except Exception as e:
        error_message = f"ERRO CRÍTICO em cadastrar_pedido: {e}"
        logger.critical(error_message, exc_info=True)
        if not any("Relatório" in log for log in logs):
            logs.insert(0, "\n--- Relatório do Cadastro/Atualização de Pedidos ---")
        logs.append(error_message)
    finally:
        if logs:
            elapsed_time = f"Tempo total de execução (Pedidos): {time.time() - start_total:.2f}s"
            logs.append(elapsed_time)
            logger.info(elapsed_time)
        return logs

if __name__ == '__main__':
    caminho_do_excel = "Cadastros Auto Nextt Importacao.xlsm"
    USUARIO_CODIGO_TESTE = 2 
    
    logger.info("="*50)
    logger.info("INÍCIO DO PROCESSO DE IMPORTAÇÃO (MODO TESTE)")
    if not os.path.exists(caminho_do_excel):
        logger.critical(f"ERRO: Arquivo de importação '{caminho_do_excel}' não encontrado.")
    elif not os.path.exists(ARQUIVO_CONEXAO):
        logger.critical(f"ERRO: Arquivo de conexão '{ARQUIVO_CONEXAO}' não encontrado.")
    else:
        logger.info("--- INICIANDO CADASTRO DE PRODUTOS ---")
        logs_produtos = cadastrar_produto(caminho_do_excel, USUARIO_CODIGO_TESTE)
        print("\n".join(logs_produtos))

        logger.info("\n" + "="*40 + "\n")
        logger.info("--- INICIANDO CADASTRO DE PEDIDOS ---")
        logs_pedidos = cadastrar_pedido(caminho_do_excel, USUARIO_CODIGO_TESTE)
        print("\n".join(logs_pedidos))

    logger.info("FIM DO PROCESSO DE IMPORTAÇÃO (MODO TESTE)")
    logger.info("="*50)