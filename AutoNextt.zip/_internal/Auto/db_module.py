# -*- coding: utf-8 -*-
import os
import sys
import json
import time
import logging
import threading
from contextlib import contextmanager
from datetime import datetime
from typing import Dict, List, Any, Iterator

# Tenta importar bibliotecas específicas do Windows
try:
    import win32com.client
    import pythoncom
    import pyodbc
    from tqdm import tqdm
except ImportError:
    print("ERRO: Este script requer as bibliotecas 'pywin32', 'pyodbc' e 'tqdm'.")
    print("Instale-as com: pip install pywin32 pyodbc tqdm")
    sys.exit(1)

# ==============================================================================
# --- CONSTANTES E CONFIGURAÇÕES GLOBAIS ---
# ==============================================================================
DEBUG = False
ARQUIVO_CONEXAO = 'conexao_temp.txt'

# Mapeamento de abas para seus respectivos arquivos de código .bas
MAPEAMENTO_ABAS_CODIGO: Dict[str, str] = {
    "Cadastro de Produtos": "cadastro_de_produtos.bas",
    "Cadastro de Marcas": "cadastro_de_marcas.bas",
    "Cadastro de Segmento": "cadastro_de_segmento.bas",
    "Cadastro de Secao": "cadastro_de_secao.bas",
    "Cadastro de Especie": "cadastro_de_especie.bas",
    "Cadastro de Pedidos": "cadastro_de_pedidos.bas"
}
ARQUIVO_AUTOEXEC = "AutoExec.bas"
ARQUIVO_JSON_CONVERTER = os.path.join("VBA-JSON-master", "JsonConverter.bas")
MACRO_CRIAR_INTERVALOS = "CriarIntervalosNomeados.CriarIntervalosNomeados"

# GUIDs para referências VBA (mais robusto que caminhos de arquivo)
# {420B2830-E718-11CF-893D-00A0C9054228} - Microsoft Scripting Runtime
GUID_SCRRUN = "{420B2830-E718-11CF-893D-00A0C9054228}"
# {B691E011-1797-432E-907A-4D8C69339129} - Microsoft ActiveX Data Objects 6.1 Library
GUID_ADO = "{B691E011-1797-432E-907A-4D8C69339129}"

CONSOLE_DISPONIVEL = sys.stdout is not None

# Configuração do logger
log_formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
log_file = 'log_execucao.txt'

# Handler para salvar em arquivo
file_handler = logging.FileHandler(log_file)
file_handler.setFormatter(log_formatter)
file_handler.setLevel(logging.INFO)

# Handler para exibir no console (se disponível)
console_handler = logging.StreamHandler()
console_handler.setFormatter(log_formatter)
console_handler.setLevel(logging.INFO)

# Adiciona os handlers ao logger principal
logger = logging.getLogger()
logger.setLevel(logging.INFO)
logger.addHandler(file_handler)

if CONSOLE_DISPONIVEL:
    logger.addHandler(console_handler)

if not CONSOLE_DISPONIVEL:
    class TqdmDummy:
        def __init__(self, *args, **kwargs):
            self.total = kwargs.get('total', 0)
            self.desc = kwargs.get('desc', '')

        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc_val, exc_tb):
            pass

        def update(self, n=1):
            pass

        def set_description(self, desc):
            self.desc = desc
            safe_print(f"[PROGRESS] {self.desc}") # Loga a mudança de descrição

    tqdm = TqdmDummy

# Substitui o safe_print padrão para que tudo seja logado
def safe_print(message):
    logger.info(message)

# ==============================================================================
# --- FUNÇÕES UTILITÁRIAS E DE CONEXÃO ---
# ==============================================================================
def recurso_path(rel_path: str) -> str:
    """Garante que o caminho do recurso funcione tanto em modo script quanto em executável."""
    try:
        base_path = sys._MEIPASS
    except AttributeError:
        current_dir = os.path.abspath(os.path.dirname(__file__))
        base_path = os.path.dirname(current_dir) if os.path.basename(current_dir) == 'Auto' else current_dir
    return os.path.join(base_path, rel_path)

def debug_print(message: str):
    """Exibe mensagens de depuração se DEBUG estiver ativado."""
    if DEBUG:
        logger.debug(f"[DEBUG] {message}")

@contextmanager
def get_db_connection() -> Iterator[pyodbc.Connection]:
    """Context manager para uma conexão de banco de dados que garante o fechamento."""
    conn = None
    try:
        with open(recurso_path(ARQUIVO_CONEXAO), "r") as f:
            params = json.load(f)
        
        if params.get("trusted_connection", "no").lower() == "yes":
            conn_str = f"DRIVER={{{params['driver']}}};SERVER={params['server']};DATABASE={params['database']};Trusted_Connection=yes;Encrypt=yes;TrustServerCertificate=yes"
        else:
            conn_str = f"DRIVER={{{params['driver']}}};SERVER={params['server']};DATABASE={params['database']};UID={params['username']};PWD={params['password']};Encrypt=yes;TrustServerCertificate=yes"
        
        conn = pyodbc.connect(conn_str)
        yield conn
    finally:
        if conn:
            conn.close()

@contextmanager
def gerenciador_excel(visible: bool = False) -> Iterator[Any]:
    """Context manager para uma instância do Excel, garantindo a inicialização e o encerramento adequados."""
    excel_app = None
    pythoncom.CoInitialize()
    try:
        debug_print("Iniciando instância do Excel via COM...")
        excel_app = win32com.client.Dispatch("Excel.Application")
        excel_app.Visible = visible
        excel_app.DisplayAlerts = False
        excel_app.AskToUpdateLinks = False
        yield excel_app
    finally:
        if excel_app:
            debug_print("Encerrando instância do Excel...")
            excel_app.Quit()
        pythoncom.CoUninitialize()
        debug_print("Recursos COM liberados.")

# ==============================================================================
# --- FUNÇÕES DE LÓGICA DE NEGÓCIO (HELPER) ---
# ==============================================================================

def _obter_nome_empresa() -> str:
    """Obtém o nome da empresa do banco de dados de forma segura."""
    debug_print("Buscando nome da empresa no banco...")
    try:
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT TOP 1 emp_descricao FROM tb_empresa WITH(NOLOCK)")
            resultado = cursor.fetchone()
        nome = resultado[0].strip() if resultado else "EmpresaDesconhecida"
        debug_print(f"Nome da empresa obtido: {nome}")
        return nome
    except (pyodbc.Error, FileNotFoundError) as e:
        safe_print(f"Erro ao buscar o nome da empresa: {e}")
        return "Erro"

def _importar_modulos_vba(workbook: Any, modulos_bas: List[str], pasta_modulos: str):
    """Importa uma lista de módulos .bas para o projeto VBA."""
    vb_project = workbook.VBProject
    pasta_modulos_abs = recurso_path(pasta_modulos)
    
    arquivos_ja_tratados = set()

    # 1. Importa código para abas específicas
    for nome_aba, nome_arquivo in MAPEAMENTO_ABAS_CODIGO.items():
        caminho_codigo_abs = os.path.join(pasta_modulos_abs, nome_arquivo)
        if os.path.exists(caminho_codigo_abs):
            try:
                sheet_component = vb_project.VBComponents(workbook.Sheets(nome_aba).CodeName)
                sheet_component.CodeModule.DeleteLines(1, sheet_component.CodeModule.CountOfLines)
                sheet_component.CodeModule.AddFromFile(caminho_codigo_abs)
                debug_print(f"Código injetado na aba '{nome_aba}'.")
                arquivos_ja_tratados.add(nome_arquivo)
            except Exception as e:
                safe_print(f"AVISO: Falha ao importar código para a aba '{nome_aba}'. Erro: {e}")

    # 2. Importa AutoExec para ThisWorkbook
    caminho_autoexec = os.path.join(pasta_modulos_abs, ARQUIVO_AUTOEXEC)
    if os.path.exists(caminho_autoexec):
        try:
            thisworkbook_component = None
            for component in vb_project.VBComponents:
                if component.Type == 100 and component.Name == workbook.CodeName:
                    thisworkbook_component = component
                    break
            
            if thisworkbook_component:
                thisworkbook_component.CodeModule.DeleteLines(1, thisworkbook_component.CodeModule.CountOfLines)
                thisworkbook_component.CodeModule.AddFromFile(caminho_autoexec)
                debug_print(f"Código de '{ARQUIVO_AUTOEXEC}' injetado em '{thisworkbook_component.Name}'.")
                arquivos_ja_tratados.add(ARQUIVO_AUTOEXEC)
            else:
                safe_print("AVISO: Não foi possível encontrar o componente de workbook ('ThisWorkbook'/'EstaPasta_de_trabalho').")
        except Exception as e:
            safe_print(f"AVISO: Falha ao injetar '{ARQUIVO_AUTOEXEC}'. Erro: {e}")

    # --- INÍCIO DA CORREÇÃO ---
    # 3. Importa JsonConverter.bas explicitamente
    caminho_json_converter = recurso_path(ARQUIVO_JSON_CONVERTER)
    if os.path.exists(caminho_json_converter):
        try:
            vb_project.VBComponents.Import(caminho_json_converter)
            debug_print(f"Módulo '{os.path.basename(ARQUIVO_JSON_CONVERTER)}' importado.")
        except Exception as e:
            if '-2147352567' in str(e):
                debug_print(f"Módulo '{os.path.basename(ARQUIVO_JSON_CONVERTER)}' já existe, ignorando importação.")
            else:
                safe_print(f"AVISO: Falha ao importar '{os.path.basename(ARQUIVO_JSON_CONVERTER)}'. Erro: {e}")
    arquivos_ja_tratados.add(os.path.basename(ARQUIVO_JSON_CONVERTER))
    # --- FIM DA CORREÇÃO ---

    # 4. Importa módulos restantes
    for modulo_path in modulos_bas:
        nome_arquivo = os.path.basename(modulo_path)
        if nome_arquivo not in arquivos_ja_tratados:
            try:
                vb_project.VBComponents.Import(modulo_path)
                debug_print(f"Módulo '{nome_arquivo}' importado.")
            except Exception as e:
                if '-2147352567' not in str(e):
                    safe_print(f"AVISO: Falha ao importar módulo '{nome_arquivo}'. Erro: {e}")
                else:
                    debug_print(f"Módulo '{nome_arquivo}' já existe, ignorando importação.")

def _criar_botoes_e_atribuir_macros(workbook: Any):
    """Cria botões de formulário e atribui macros."""
    config_botoes = {
        "Cadastro de Segmento": ("A6", "A6", "ExecutarCadastroSegmento"),
        "Cadastro de Secao": ("A6", "B6", "ExecutarCadastroSecao"),
        "Cadastro de Especie": ("A6", "B6", "ExecutarCadastroEspecie"),
        "Cadastro de Marcas": ("A6", "A6", "ExecutarCadastroMarca"),
    }
    for nome_aba, (pos_cell, width_cell, macro) in config_botoes.items():
        try:
            sheet = workbook.Sheets(nome_aba)
            left = sheet.Range(pos_cell).Left
            top = sheet.Range(pos_cell).Top
            height = sheet.Range(pos_cell).Height
            width = sheet.Range(width_cell).Left + sheet.Range(width_cell).Width - left
            button = sheet.Shapes.AddFormControl(5, left, top, width, height)
            button.TextFrame.Characters().Text = "Executar Cadastro"
            button.OnAction = macro
        except Exception as e:
            safe_print(f"AVISO: Falha ao criar botão na aba '{nome_aba}'. Erro: {e}")

def _adicionar_referencias_vba(workbook: Any):
    """Adiciona referências VBA ao projeto usando GUIDs."""
    vb_project = workbook.VBProject
    for nome_ref, guid in {"Scripting": GUID_SCRRUN, "ADO": GUID_ADO}.items():
        try:
            vb_project.References.AddFromGuid(guid, 0, 0)
            debug_print(f"Referência VBA '{nome_ref}' adicionada.")
        except Exception:
            debug_print(f"Referência VBA '{nome_ref}' provavelmente já existe.")

def _criar_atalho_area_trabalho(caminho_planilha: str, nome_empresa: str, timestamp: str):
    """Cria um atalho para a planilha na área de trabalho do usuário."""
    try:
        desktop = os.path.join(os.environ['USERPROFILE'], 'Desktop')
        nome_atalho = f"Cadastros Auto Nextt {nome_empresa} - {timestamp}.lnk"
        caminho_atalho = os.path.join(desktop, nome_atalho)
        
        shell = win32com.client.Dispatch("WScript.Shell")
        atalho = shell.CreateShortCut(caminho_atalho)
        atalho.TargetPath = os.path.abspath(caminho_planilha)
        atalho.WorkingDirectory = os.path.dirname(os.path.abspath(caminho_planilha))
        atalho.Save()
        safe_print(f"Atalho criado na área de trabalho: {nome_atalho}")
    except Exception as e:
        safe_print(f"AVISO: Não foi possível criar o atalho na área de trabalho. Erro: {e}")

def _abrir_planilha(caminho_planilha: str):
    """Abre um arquivo usando o programa padrão do sistema."""
    try:
        os.startfile(os.path.abspath(caminho_planilha))
        safe_print("Planilha final aberta para o usuário.")
    except Exception as e:
        safe_print(f"AVISO: Não foi possível abrir a planilha automaticamente. Erro: {e}")

# ==============================================================================
# --- FUNÇÃO ORQUESTRADORA PRINCIPAL (NOME MANTIDO) ---
# ==============================================================================

def importar_modulo_vba(caminho_xlsx: str, modulos_vba: List[str], pasta_modulos: str):
    """
    Orquestra todo o processo: converte a planilha, injeta código VBA, cria UI e finaliza.
    """
    inicio_total = time.time()
    etapas_total = 7
    caminho_xlsm_final = None

    safe_print("Iniciando processo de preparação da planilha com macros...")
    try:
        with tqdm(total=etapas_total, desc="Iniciando", unit="etapa") as pbar:
            
            pbar.set_description("Buscando dados da empresa")
            nome_empresa = _obter_nome_empresa()
            if nome_empresa == "Erro": raise RuntimeError("Não foi possível obter o nome da empresa do banco.")
            pbar.update(1)

            with gerenciador_excel() as excel_app:
                # ETAPA 1: Converter .xlsx para .xlsm
                pbar.set_description("Convertendo planilha")
                caminho_xlsx_abs = os.path.abspath(recurso_path(caminho_xlsx))
                timestamp = datetime.now().strftime("%d-%m-%Y-%H_%M")
                base_name = os.path.splitext(caminho_xlsx_abs)[0]
                caminho_xlsm_final = f"{base_name} {nome_empresa} - {timestamp}.xlsm"
                
                source_wb = excel_app.Workbooks.Open(caminho_xlsx_abs)
                source_wb.SaveAs(caminho_xlsm_final, FileFormat=52)
                source_wb.Close(SaveChanges=False)
                pbar.update(1)

                # ETAPA 2: Abrir o .xlsm e realizar todas as operações
                pbar.set_description("Injetando código VBA")
                workbook = excel_app.Workbooks.Open(caminho_xlsm_final)
                try:
                    if workbook.VBProject.Protection == 1:
                        raise RuntimeError("O projeto VBA está protegido. Remova a proteção antes de continuar.")

                    _importar_modulos_vba(workbook, modulos_vba, pasta_modulos)
                    pbar.update(1)

                    pbar.set_description("Adicionando referências")
                    _adicionar_referencias_vba(workbook)
                    pbar.update(1)
                    
                    pbar.set_description("Criando interface")
                    _criar_botoes_e_atribuir_macros(workbook)
                    excel_app.Application.Run(MACRO_CRIAR_INTERVALOS)
                    pbar.update(1)
                    
                    pbar.set_description("Salvando alterações")
                    workbook.Save()
                finally:
                    if 'workbook' in locals() and workbook:
                        workbook.Close(SaveChanges=False)

        # ETAPAS PÓS-EXCEL
        if caminho_xlsm_final:
            pbar.set_description("Criando atalho")
            _criar_atalho_area_trabalho(caminho_xlsm_final, nome_empresa, timestamp)
            if os.path.exists(caminho_xlsx):
                os.remove(caminho_xlsx)

            _abrir_planilha(caminho_xlsm_final)
            pbar.update(1)
            
            safe_print("Processo Concluído")
            pbar.set_description("Processo Concluído")
            pbar.update(1)
        
        safe_print("\nOperação finalizada com sucesso!")

    except Exception as e:
        logger.critical(f"ERRO CRÍTICO: O processo foi interrompido. Detalhes: {e}")
        logger.exception("O rastreamento completo do erro é:")
    finally:
        tempo_total = time.time() - inicio_total
        safe_print(f"Tempo total de execução: {tempo_total:.2f} segundos.")
        safe_print("O log completo da execução foi salvo em 'log_execucao.txt'.")

# ==============================================================================
# --- FUNÇÕES LEGADAS ---
# ==============================================================================
def obter_nome_empresa():
    """Mantida por compatibilidade. A lógica agora está em _obter_nome_empresa."""
    return _obter_nome_empresa()

def converter_xlsx_para_xlsm(*args, **kwargs):
    safe_print("AVISO: A função 'converter_xlsx_para_xlsm' foi descontinuada para evitar múltiplas instâncias do Excel.")
    return None

def adicionar_referencia_vba(*args, **kwargs):
    safe_print("AVISO: A função 'adicionar_referencia_vba' foi descontinuada.")
    
def encerrar_processos_excel():
    safe_print("AVISO: A função 'encerrar_processos_excel' foi removida por segurança.")

# ==============================================================================
# --- BLOCO DE EXECUÇÃO PARA TESTE ---
# ==============================================================================
if __name__ == '__main__':
    caminho_xlsx_teste = "Cadastros Auto Nextt.xlsx"
    pasta_modulos_teste = "Module"

    if not all(os.path.exists(recurso_path(p)) for p in [caminho_xlsx_teste, pasta_modulos_teste, ARQUIVO_CONEXAO]):
        safe_print("ERRO: Um ou mais arquivos/pastas necessários para o teste não foram encontrados.")
        safe_print(f"Verifique a existência de: '{caminho_xlsx_teste}', '{pasta_modulos_teste}', '{ARQUIVO_CONEXAO}'")
    else:
        # A lista de módulos agora inclui todos os arquivos .bas da pasta Module
        lista_modulos = [os.path.join(pasta_modulos_teste, f) for f in os.listdir(recurso_path(pasta_modulos_teste)) if f.endswith(".bas")]
        
        # A importação do JsonConverter é tratada internamente na função principal agora,
        # então não é mais necessário adicioná-lo a esta lista.
        
        importar_modulo_vba(
            caminho_xlsx=caminho_xlsx_teste,
            modulos_vba=lista_modulos,
            pasta_modulos=pasta_modulos_teste
        )