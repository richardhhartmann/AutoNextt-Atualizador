# -*- coding: utf-8 -*-
import pandas as pd
import pyodbc
import os
import json
import sys
import openpyxl
import time
import warnings
import logging
from datetime import datetime
from openpyxl.utils import get_column_letter, column_index_from_string
from contextlib import contextmanager
from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional, Tuple

# ==============================================================================
# --- CONFIGURAÇÕES GLOBAIS E DE LOGGING ---
# ==============================================================================
DEBUG = True
BATCH_SIZE = 100
ARQUIVO_CONEXAO = 'conexao_temp.txt'

# --- Configuração de Logging ---
log_formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
log_file = 'log_importacao.txt'

# Limpa handlers antigos para evitar logs duplicados
logger = logging.getLogger()
if logger.hasHandlers():
    logger.handlers.clear()

# Handler para arquivo
file_handler = logging.FileHandler(log_file, mode='w', encoding='utf-8')
file_handler.setFormatter(log_formatter)
logger.addHandler(file_handler)

# Handler para console (se disponível)
if sys.stdout is not None:
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(log_formatter)
    logger.addHandler(console_handler)

# Define o nível do log com base na flag DEBUG
logger.setLevel(logging.DEBUG if DEBUG else logging.INFO)
warnings.filterwarnings("ignore", category=UserWarning, module="openpyxl")


# --- Constantes para a planilha "Cadastro de Produtos" ---
PRODUTO_SHEET_NAME = "Cadastro de Produtos"
PRODUTO_HEADER_ROW = 3
PRODUTO_DATA_START_ROW = 7
PRODUTO_COL_INICIAL_ADICIONAIS = 'BD'
PRODUTO_COL_LIMITE_ADICIONAIS = 'CF'
PRODUTO_STATUS_OK = "OK"
PRODUTO_COLS_CORES = ['R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'AA', 'AB', 'AC', 'AD', 'AE', 'AF', 'AG', 'AH', 'AI', 'AJ']
PRODUTO_COLS_TAMANHOS = ['AK', 'AL', 'AM', 'AN', 'AO', 'AP', 'AQ', 'AR', 'AS', 'AT', 'AU', 'AV', 'AW', 'AX', 'AY', 'AZ', 'BA', 'BB', 'BC']

# --- Constantes para a planilha "Cadastro de Pedidos" ---
PEDIDO_SHEET_NAME = "Cadastro de Pedidos"
PEDIDO_DATA_START_ROW = 7
PEDIDO_COL_COD_ORIGINAL = 0
PEDIDO_COL_DT_ENTREGA_INICIAL = 3
PEDIDO_COL_DT_ENTREGA_FINAL = 4
PEDIDO_COL_OBSERVACAO = 8
PEDIDO_COL_FORNECEDOR = 702
PEDIDO_COL_COMPRADOR = 703
PEDIDO_COL_CONDICAO_PAG = 704
PEDIDO_COL_PARCELAS = 705
PEDIDO_COL_ATRIBUTO = 706
PEDIDO_COL_START_PAGAMENTOS = 707
PEDIDO_COL_QUALIDADE = 6
PEDIDO_COLS_PRODUTO_COD = range(11, 21)
PEDIDO_COLS_PRODUTO_CUSTO = range(21, 31)
PEDIDO_COL_START_FILIAIS = 39

# --- QUERIES SQL  ---
SQL_GET_MAX_PRODUTO_CODIGO = "SELECT sec_codigo, esp_codigo, ISNULL(MAX(prd_codigo), 0) as max_codigo FROM tb_produto WITH(NOLOCK) GROUP BY sec_codigo, esp_codigo;"
SQL_CHECK_DUPLICADOS_PRODUTO = "SELECT t.Referencia, t.Marca FROM #TempDuplicados t INNER JOIN tb_produto p WITH(NOLOCK) ON p.prd_referencia_fornec = t.Referencia AND p.mar_codigo = t.Marca;"
SQL_GET_TPA_CODIGOS = "SELECT tpa_codigo FROM tb_tipo_atributo WITH(NOLOCK) WHERE tpa_codigo > 2 AND tba_codigo = 1 AND tpa_ordem = 0 ORDER BY tpa_codigo;"
SQL_INSERT_PRODUTO = "INSERT INTO tb_produto (sec_codigo, esp_codigo, prd_codigo, prd_descricao, prd_descricao_reduzida, mar_codigo, prd_data_cadastro, prd_unidade, prd_data_ultima_compra, prd_data_ultima_entrega, prd_custo_medio, prd_preco_medio, prd_aliquota_icms, prd_codigo_original, prd_ativo, prd_ultimo_custo, prd_arquivo_foto, prd_referencia_fornec, prd_tipo_tributacao, clf_codigo, usu_codigo_comprador, und_codigo, prd_valor_venda, prd_origem, prd_percentual_icms, prd_percentual_ipi, etq_codigo_padrao, usu_codigo_cadastro, sec_codigo_r, esp_codigo_r, prd_permite_comprar, prd_valor_unidade_conversao, udc_codigo, und_codigo_conversao, prd_iat, prd_ippt) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);"
SQL_INSERT_ATRIBUTO_PRODUTO = "INSERT INTO tb_atributo_produto (sec_codigo, esp_codigo, prd_codigo, tpa_codigo, apr_descricao) VALUES (?, ?, ?, ?, ?);"
SQL_INSERT_ITEM_PRODUTO = "INSERT INTO tb_item_produto (sec_codigo, esp_codigo, prd_codigo, ipr_codigo, ipr_codigo_barra, ipr_preco_promocional) VALUES (?, ?, ?, ?, ?, 0);"
SQL_INSERT_ATRIBUTO_ITEM_PRODUTO = "INSERT INTO tb_atributo_item_produto (sec_codigo, esp_codigo, prd_codigo, ipr_codigo, tpa_codigo, aip_descricao, aip_ordem) VALUES (?, ?, ?, ?, ?, ?, ?);"
SQL_GET_MAX_PEDIDO_CODIGO = "SELECT ISNULL(MAX(ped_codigo), 0) FROM tb_pedido WITH(NOLOCK);"
SQL_GET_FILIAIS = "SELECT fil_codigo FROM tb_filial WITH(NOLOCK) ORDER BY fil_codigo;"
SQL_INSERT_PEDIDO = "INSERT INTO tb_pedido (ped_codigo, pes_codigo, usu_codigo_comprador, ped_data_emissao, ped_data_entrega_inicial, ped_data_entrega_final, ped_status, ped_observacao, ped_codigo_original, ped_qualidade, cpg_codigo, ped_data_cadastro, usu_codigo_cadastro, ped_data_ult_alteracao) VALUES (?, ?, ?, ?, ?, ?, 'D', ?, ?, ?, ?, ?, ?, ?);"
SQL_INSERT_PEDIDO_PRODUTO = "INSERT INTO tb_pedido_produto (ped_codigo, sec_codigo, esp_codigo, prd_codigo, ppr_custo_medio) VALUES (?, ?, ?, ?, ?);"
SQL_INSERT_ITEM_PEDIDO = "INSERT INTO tb_item_pedido (ped_codigo, sec_codigo, esp_codigo, prd_codigo, ipr_codigo, fil_codigo, ipd_pack, ipd_qtde_pedido, ipd_valor_custo, ipd_fator_grade, ipd_fator_filial, ipd_qtde_entregue, ipd_valor_desconto, ipd_valor_icms, ipd_valor_ipi) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0.0, 0.0, 0.0, 0.0);"
SQL_INSERT_TIPO_DOCUMENTO = "INSERT INTO tb_pedido_tipo_documento(ped_codigo, tid_codigo) VALUES (?, ?);"
SQL_DELETE_TIPO_DOCUMENTO = "DELETE FROM tb_pedido_tipo_documento WHERE ped_codigo = ?;"
SQL_GET_VARIACOES_PRODUTO = "SELECT ipr_codigo FROM tb_item_produto WITH(NOLOCK) WHERE sec_codigo = ? AND esp_codigo = ? AND prd_codigo = ?;"



# ==============================================================================
# --- CLASSES DE DADOS (DATACLASSES) ---
# ==============================================================================

@dataclass
class Variacao:
    ipr_codigo: int; tpa_codigo: int; valor: str; ordem: int
    ipr_codigo_barra: Optional[str] = None

@dataclass
class Produto:
    # Campos existentes
    linha_excel: int
    secao: int
    especie: int
    prd_codigo: int
    descricao: str
    descricao_reduzida: str
    marca: int
    referencia: str
    data_cadastro: datetime
    cod_original: Optional[str] = None
    comprador: Optional[int] = None
    und_codigo: Optional[int] = None
    classificacao: Optional[int] = None
    origem: Optional[int] = None
    etiqueta: Optional[int] = None
    venda: Optional[float] = None
    icms: Optional[float] = None  # prd_percentual_icms
    ipi: Optional[float] = None   # prd_percentual_ipi
    ativo: int = 1
    
    # Novos campos adicionados com valores padrão
    prd_unidade: Optional[str] = None
    prd_data_ultima_compra: Optional[datetime] = None
    prd_data_ultima_entrega: Optional[datetime] = None
    prd_custo_medio: float = 0.0
    prd_preco_medio: float = 0.0
    prd_aliquota_icms: float = 0.0
    prd_ultimo_custo: Optional[float] = None
    prd_arquivo_foto: Optional[str] = None
    prd_tipo_tributacao: Optional[str] = None
    usu_codigo_cadastro: Optional[int] = None
    sec_codigo_r: Optional[int] = None
    esp_codigo_r: Optional[int] = None
    prd_permite_comprar: int = 1
    prd_valor_unidade_conversao: Optional[float] = None
    udc_codigo: Optional[int] = None
    und_codigo_conversao: Optional[int] = None
    prd_iat: Optional[str] = None
    prd_ippt: Optional[str] = None

    # Campos de relacionamento (sem alterações)
    atributos_adicionais: List[Tuple[int, str]] = field(default_factory=list)
    variacoes: List[Variacao] = field(default_factory=list)

@dataclass
class ItemPedido:
    sec_codigo: int; 
    esp_codigo: int; 
    prd_codigo: int; 
    custo: float
    fatores_filial: Dict[int, int]

@dataclass
class Pedido:
    linha_excel: int; ped_codigo: int; comprador: Optional[int]; dt_emissao: datetime
    fornecedor: Optional[str] 
    dt_entrega_inicial: Optional[datetime]; dt_entrega_final: Optional[datetime]
    observacao: Optional[str]; cod_original: Optional[int]; qualidade: Optional[float]
    condicao_pagamento: int
    formas_pagamento: List[int] = field(default_factory=list)
    itens: List[ItemPedido] = field(default_factory=list)


# ==============================================================================
# --- FUNÇÕES UTILITÁRIAS E DE BANCO ---
# ==============================================================================
def recurso_path(rel_path: str) -> str:
    try:
        base_path = sys._MEIPASS
    except AttributeError:
        base_path = os.path.abspath(".")
    return os.path.join(base_path, rel_path)

@contextmanager
def get_db_connection(commit_on_exit: bool = False):
    conn: Optional[pyodbc.Connection] = None
    try:
        with open(recurso_path(ARQUIVO_CONEXAO), 'r') as f:
            config = json.load(f)
        driver, server, database = config.get('driver'), config.get('server'), config.get('database')
        if config.get('trusted_connection', 'no').lower() == 'yes':
            conn_str = f"DRIVER={{{driver}}};SERVER={server};DATABASE={database};Trusted_Connection=yes;Encrypt=yes;TrustServerCertificate=yes"
        else:
            conn_str = f"DRIVER={{{driver}}};SERVER={server};DATABASE={database};UID={config.get('username')};PWD={config.get('password')};Encrypt=yes;TrustServerCertificate=yes"
        conn = pyodbc.connect(conn_str, autocommit=False)
        logger.debug("Conexão com o banco estabelecida.")
        yield conn
        if commit_on_exit and conn: 
            conn.commit()
            logger.debug("Transação commitada com sucesso.")
    except Exception as e:
        if conn: 
            conn.rollback()
            logger.error("Transação revertida (rollback) devido a erro.")
        logger.critical(f"ERRO de conexão/operação: {e}")
        raise
    finally:
        if conn: 
            conn.close()
            logger.debug("Conexão com o banco fechada.")

def trata_valor(valor: Any, tipo_saida: type = int) -> Optional[Any]:
    if pd.isna(valor): return None
    valor_str = str(valor).strip()
    if not valor_str or valor_str.upper() in ['#N/D', '#N/A', 'N/D']: return None

    try:
        if tipo_saida == str:
            return valor_str
        
        valor_float = float(valor_str.replace(',', '.'))
        return int(valor_float) if tipo_saida == int else tipo_saida(valor_float)
    except (ValueError, TypeError):
        return None

# ==============================================================================
# --- SEÇÃO DE CADASTRO DE PRODUTO ---
# ==============================================================================
def _get_colunas_adicionais(ws: openpyxl.worksheet.worksheet.Worksheet) -> List[str]:
    colunas = []
    idx_inicial = column_index_from_string(PRODUTO_COL_INICIAL_ADICIONAIS)
    idx_limite = column_index_from_string(PRODUTO_COL_LIMITE_ADICIONAIS)
    for current_col_idx in range(idx_inicial, idx_limite + 1):
        col_letter = get_column_letter(current_col_idx)
        valor = ws[f'{col_letter}{PRODUTO_HEADER_ROW}'].value
        if pd.isna(valor) or not valor: break
        colunas.append(col_letter)
    return colunas

def _get_tpa_codigos_map(cursor: pyodbc.Cursor, colunas_adicionais: List[str]) -> Dict[str, int]:
    cursor.execute(SQL_GET_TPA_CODIGOS)
    tpa_codes = [row.tpa_codigo for row in cursor.fetchall()]
    return {col_letter: tpa_code for col_letter, tpa_code in zip(colunas_adicionais, tpa_codes)}

def _get_proximos_codigos_produto(cursor: pyodbc.Cursor) -> Dict[Tuple[int, int], int]:
    cursor.execute(SQL_GET_MAX_PRODUTO_CODIGO)
    return {(row.sec_codigo, row.esp_codigo): row.max_codigo for row in cursor.fetchall()}

def _verificar_duplicados_produto(cursor: pyodbc.Cursor, referencias_marcas: List[Tuple[str, int]]) -> set:
    if not referencias_marcas: return set()
    logger.debug(f"Verificando {len(referencias_marcas)} combinações de referência/marca por duplicados.")
    cursor.execute("CREATE TABLE #TempDuplicados (Referencia NVARCHAR(50), Marca INT)")
    try:
        cursor.executemany("INSERT INTO #TempDuplicados (Referencia, Marca) VALUES (?, ?)", referencias_marcas)
        cursor.execute(SQL_CHECK_DUPLICADOS_PRODUTO)
        duplicados = set((row.Referencia, row.Marca) for row in cursor.fetchall())
        logger.debug(f"Encontrados {len(duplicados)} produtos duplicados no banco.")
        return duplicados
    finally:
        cursor.execute("DROP TABLE #TempDuplicados")

def _prepare_produtos_from_excel(ws: openpyxl.worksheet.worksheet.Worksheet, df: pd.DataFrame, tpa_codigos_map: Dict, codigos_produto: Dict) -> List[Produto]:
    produtos_para_inserir = []
    colunas_adicionais_letras = list(tpa_codigos_map.keys())
    for i, row in df.iterrows():
        linha_excel = i + PRODUTO_DATA_START_ROW
        if row.iloc[199] != PRODUTO_STATUS_OK:
            logger.debug(f"Linha {linha_excel} ignorada: Status não é 'OK'.")
            continue
        secao, especie = trata_valor(row.iloc[84], int), trata_valor(row.iloc[85], int)
        if not secao or not especie:
            logger.warning(f"Linha {linha_excel} ignorada: Seção ou Espécie inválida.")
            continue
        
        logger.debug(f"Processando produto da linha Excel: {linha_excel}")
        
        chave_codigo = (secao, especie)
        codigos_produto[chave_codigo] = codigos_produto.get(chave_codigo, 0) + 1
        prd_codigo = codigos_produto[chave_codigo]
        
        cores = [str(ws[f'{c}{linha_excel}'].value).strip() for c in PRODUTO_COLS_CORES if pd.notna(ws[f'{c}{linha_excel}'].value)]
        tamanhos = [str(ws[f'{t}{linha_excel}'].value).strip() for t in PRODUTO_COLS_TAMANHOS if pd.notna(ws[f'{t}{linha_excel}'].value)]
        variacoes, ipr_counter = [], 1
        for ordem, cor in enumerate(cores, 1):
            variacoes.append(Variacao(ipr_codigo=ipr_counter, tpa_codigo=1, valor=cor, ordem=ordem)); ipr_counter += 1
        for ordem, tamanho in enumerate(tamanhos, 1):
            variacoes.append(Variacao(ipr_codigo=ipr_counter, tpa_codigo=2, valor=tamanho, ordem=ordem)); ipr_counter += 1

        atributos = [(tpa_codigos_map[col], str(ws[f"{col}{linha_excel}"].value)) for col in colunas_adicionais_letras if pd.notna(ws[f"{col}{linha_excel}"].value) and col in tpa_codigos_map]
        ref_raw = row.iloc[5]
        referencia = str(int(ref_raw)) if isinstance(ref_raw, float) and ref_raw.is_integer() else str(ref_raw) if pd.notna(ref_raw) else None
        
        produtos_para_inserir.append(Produto(linha_excel=linha_excel, secao=secao, especie=especie, prd_codigo=prd_codigo, descricao=str(row.iloc[2])[:50], descricao_reduzida=str(row.iloc[3])[:50], marca=trata_valor(row.iloc[86], int), referencia=referencia, data_cadastro=datetime.now(),cod_original=str(row.iloc[6]) if pd.notna(row.iloc[6]) else None, comprador=trata_valor(row.iloc[87], int), und_codigo=trata_valor(row.iloc[88], int), classificacao=trata_valor(row.iloc[89], int), origem=trata_valor(row.iloc[90], int),etiqueta=trata_valor(row.iloc[91], int), venda=trata_valor(row.iloc[12], float), icms=trata_valor(row.iloc[13], float),ipi=trata_valor(row.iloc[14], float), variacoes=variacoes, atributos_adicionais=atributos))
    return produtos_para_inserir

def _insert_produtos_em_lote(cursor: pyodbc.Cursor, produtos: List[Produto]):
    params_produto, params_atr_prod, params_item, params_atr_item = [], [], [], []
    
    for p in produtos:
        # A tupla de parâmetros agora contém todos os 36 campos na ordem correta
        params_produto.append((
            p.secao, p.especie, p.prd_codigo, p.descricao, p.descricao_reduzida,
            p.marca, p.data_cadastro, p.prd_unidade, p.prd_data_ultima_compra,
            p.prd_data_ultima_entrega, p.prd_custo_medio, p.prd_preco_medio, p.prd_aliquota_icms,
            p.cod_original, p.ativo, p.prd_ultimo_custo, p.prd_arquivo_foto,
            p.referencia, p.prd_tipo_tributacao, p.classificacao, p.comprador,
            p.und_codigo, p.venda, p.origem, p.icms, p.ipi,
            p.etiqueta, p.usu_codigo_cadastro, p.sec_codigo_r, p.esp_codigo_r,
            p.prd_permite_comprar, p.prd_valor_unidade_conversao, p.udc_codigo,
            p.und_codigo_conversao, p.prd_iat, p.prd_ippt
        ))
        
        # O resto da lógica para atributos e itens permanece igual
        params_atr_prod.extend([(p.secao, p.especie, p.prd_codigo, tpa, desc) for tpa, desc in p.atributos_adicionais])
        for v in p.variacoes:
            params_item.append((p.secao, p.especie, p.prd_codigo, v.ipr_codigo, v.ipr_codigo_barra))
            params_atr_item.append((p.secao, p.especie, p.prd_codigo, v.ipr_codigo, v.tpa_codigo, v.valor, v.ordem))

    # --- INÍCIO DO NOVO BLOCO DE DEBUG ---
    if DEBUG and params_produto:
        log_msgs = ["\n" + "="*20 + " DEBUG INSERT tb_produto " + "="*20]
        # Usamos .strip() para remover espaços extras da query multi-linha
        log_msgs.append(f"Query: {SQL_INSERT_PRODUTO.strip()}")
        
        colunas_produto = [
            'sec_codigo', 'esp_codigo', 'prd_codigo', 'prd_descricao', 'prd_descricao_reduzida',
            'mar_codigo', 'prd_data_cadastro', 'prd_unidade', 'prd_data_ultima_compra',
            'prd_data_ultima_entrega', 'prd_custo_medio', 'prd_preco_medio', 'prd_aliquota_icms',
            'prd_codigo_original', 'prd_ativo', 'prd_ultimo_custo', 'prd_arquivo_foto',
            'prd_referencia_fornec', 'prd_tipo_tributacao', 'clf_codigo', 'usu_codigo_comprador',
            'und_codigo', 'prd_valor_venda', 'prd_origem', 'prd_percentual_icms', 'prd_percentual_ipi',
            'etq_codigo_padrao', 'usu_codigo_cadastro', 'sec_codigo_r', 'esp_codigo_r',
            'prd_permite_comprar', 'prd_valor_unidade_conversao', 'udc_codigo',
            'und_codigo_conversao', 'prd_iat', 'prd_ippt'
        ]

        log_msgs.append(f"\nTentando inserir {len(params_produto)} registro(s) em tb_produto:")
        for i, registro in enumerate(params_produto):
            log_msgs.append(f"\n--- Registro de Produto {i+1} ---")
            for col, val in zip(colunas_produto, registro):
                log_msgs.append(f"  - {col}: {val} (Tipo: {type(val).__name__})")
        
        log_msgs.append("="*60 + "\n")
        logger.debug("\n".join(log_msgs))
    # --- FIM DO NOVO BLOCO DE DEBUG ---

    # As chamadas executemany permanecem as mesmas
    if params_produto: 
        cursor.executemany(SQL_INSERT_PRODUTO, params_produto)
    if params_atr_prod: 
        cursor.executemany(SQL_INSERT_ATRIBUTO_PRODUTO, params_atr_prod)
    if params_item: 
        cursor.executemany(SQL_INSERT_ITEM_PRODUTO, params_item)
    if params_atr_item: 
        cursor.executemany(SQL_INSERT_ATRIBUTO_ITEM_PRODUTO, params_atr_item)
        
    return len(params_produto), len(params_atr_item)

def cadastrar_produto(excel_path: str):
    start_total = time.time()
    if not excel_path: return
    wb = None
    try:
        logger.info(f"Carregando arquivo Excel para produtos: {excel_path}")
        wb = openpyxl.load_workbook(excel_path, data_only=True, read_only=True)
        ws = wb[PRODUTO_SHEET_NAME]
        df = pd.read_excel(excel_path, sheet_name=PRODUTO_SHEET_NAME, skiprows=PRODUTO_DATA_START_ROW - 1, header=None).dropna(how='all')
        
        with get_db_connection(commit_on_exit=True) as conn:
            cursor = conn.cursor()
            col_adicionais = _get_colunas_adicionais(ws)
            tpa_map = _get_tpa_codigos_map(cursor, col_adicionais)
            cod_prod_base = _get_proximos_codigos_produto(cursor)
            
            produtos_a_processar = _prepare_produtos_from_excel(ws, df, tpa_map, cod_prod_base)
            logger.info(f"Total de {len(produtos_a_processar)} produtos preparados da planilha.")
            
            ref_marcas = [(p.referencia, p.marca) for p in produtos_a_processar if p.referencia and p.marca]
            duplicados = _verificar_duplicados_produto(cursor, ref_marcas)
            
            produtos_finais = [p for p in produtos_a_processar if (p.referencia, p.marca) not in duplicados]
            
            for i in range(0, len(produtos_finais), BATCH_SIZE):
                _insert_produtos_em_lote(cursor, produtos_finais[i:i + BATCH_SIZE])
                logger.info(f"Lote {i//BATCH_SIZE + 1} de produtos inserido no banco.")

        resumo_header = "\n--- Resumo do Cadastro de Produtos ---"
        resumo_aptos = f"- Produtos na planilha (aptos): {len(produtos_a_processar)}"
        resumo_ignorados = f"- Produtos já existentes (ignorados): {len(duplicados)}"
        resumo_inseridos = f"- Novos produtos inseridos: {len(produtos_finais)}"

        logger.info(resumo_header)
        logger.info(resumo_aptos)
        logger.info(resumo_ignorados)
        logger.info(resumo_inseridos)

    except Exception as e:
        logger.critical(f"ERRO CRÍTICO em cadastrar_produto: {e}")
        logger.exception("Rastreamento completo do erro:")
        return "Ocorreu um erro no cadastro de produtos. Verifique o log."
    finally:
        if wb: wb.close()
        logger.info(f"Tempo total (Produtos): {time.time() - start_total:.2f}s")


# ==============================================================================
# --- SEÇÃO DE CADASTRO DE PEDIDO ---
# ==============================================================================
def _prepare_pedidos_from_excel(df: pd.DataFrame, filiais: List[int], proximo_ped_codigo: int) -> List[Pedido]:
    pedidos = []
    for i, row in df.iterrows():
        linha_excel = i + PEDIDO_DATA_START_ROW
        fornecedor_id = trata_valor(row.iloc[PEDIDO_COL_FORNECEDOR], str)
        if not fornecedor_id:
            #logger.debug(f"Linha {linha_excel} de pedido ignorada: Fornecedor não preenchido.")
            continue
        
        logger.debug(f"Processando pedido da linha Excel: {linha_excel}")
        
        itens_pedido = []
        for j, col_idx in enumerate(PEDIDO_COLS_PRODUTO_COD):
            cod_produto_completo = trata_valor(row.iloc[col_idx], str)
            if not cod_produto_completo: continue
            try:
                if '.' in cod_produto_completo:
                    cod_produto_completo = cod_produto_completo.split('.')[0]
                cod_produto_completo = cod_produto_completo.zfill(9)
                sec_codigo, esp_codigo, prd_codigo = int(cod_produto_completo[:3]), int(cod_produto_completo[3:5]), int(cod_produto_completo[5:9])
                
                fatores_filial = {}
                col_fator_start = PEDIDO_COL_START_FILIAIS + (j * len(filiais))
                for k, fil_codigo in enumerate(filiais):
                    valor_fator_raw = row.iloc[col_fator_start + k]
                    fator_float = trata_valor(valor_fator_raw, float)
                    if fator_float is not None and fator_float > 0:
                        fatores_filial[fil_codigo] = int(fator_float)
                
                if fatores_filial:
                    itens_pedido.append(ItemPedido(
                        sec_codigo=sec_codigo, esp_codigo=esp_codigo, prd_codigo=prd_codigo,
                        custo=trata_valor(row.iloc[PEDIDO_COLS_PRODUTO_CUSTO[j]], float) or 0.0,
                        fatores_filial=fatores_filial
                    ))
            except (ValueError, IndexError, TypeError) as e:
                logger.warning(f"AVISO: Erro ao processar item na linha {linha_excel}, produto {j+1} (Código: {cod_produto_completo}). Erro: {e}")
                continue
        
        if not itens_pedido:
            logger.debug(f"Linha {linha_excel} ignorada: Nenhum item de pedido válido encontrado.")
            continue
            
        formas_pagamento = [val for k in range(PEDIDO_COL_START_PAGAMENTOS, len(row)) if (val := trata_valor(row.iloc[k], int))]
        
        pedidos.append(Pedido(
            linha_excel=linha_excel, ped_codigo=proximo_ped_codigo,
            fornecedor=fornecedor_id,
            comprador=trata_valor(row.iloc[PEDIDO_COL_COMPRADOR], int),
            dt_emissao=datetime.now(), dt_entrega_inicial=pd.to_datetime(row.iloc[PEDIDO_COL_DT_ENTREGA_INICIAL], errors='coerce'),
            dt_entrega_final=pd.to_datetime(row.iloc[PEDIDO_COL_DT_ENTREGA_FINAL], errors='coerce'),
            observacao=str(row.iloc[PEDIDO_COL_OBSERVACAO]) if pd.notna(row.iloc[PEDIDO_COL_OBSERVACAO]) else None,
            cod_original=trata_valor(row.iloc[PEDIDO_COL_COD_ORIGINAL], int), qualidade=trata_valor(row.iloc[PEDIDO_COL_QUALIDADE], float),
            condicao_pagamento=trata_valor(row.iloc[PEDIDO_COL_CONDICAO_PAG], int) or 1,
            formas_pagamento=formas_pagamento, itens=itens_pedido
        ))
        proximo_ped_codigo += 1
    return pedidos

def _insert_pedidos_em_lote(cursor: pyodbc.Cursor, pedidos: List[Pedido]):
    params_pedido, params_ped_prod, params_item_ped, params_tipo_doc = [], [], [], []
    
    # Mapeamento para guardar as variações já buscadas e evitar queries repetidas
    cache_variacoes = {}

    for p in pedidos:
        # A preparação de params_pedido e params_tipo_doc continua igual
        params_pedido.append((p.ped_codigo, p.fornecedor, p.comprador, p.dt_emissao, p.dt_entrega_inicial, p.dt_entrega_final, p.observacao, p.cod_original, p.qualidade, p.condicao_pagamento, p.dt_emissao, None, p.dt_emissao))
        params_tipo_doc.extend([(p.ped_codigo, tid) for tid in p.formas_pagamento])
        
        # A preparação de tb_pedido_produto também continua igual
        itens_unicos = {(item.sec_codigo, item.esp_codigo, item.prd_codigo): item.custo for item in p.itens}
        params_ped_prod.extend([(p.ped_codigo, sec, esp, prd, custo) for (sec, esp, prd), custo in itens_unicos.items()])

        # --- INÍCIO DA NOVA LÓGICA PARA tb_item_pedido ---
        for item in p.itens:
            chave_produto = (item.sec_codigo, item.esp_codigo, item.prd_codigo)

            # Busca as variações no banco de dados (usando um cache para performance)
            if chave_produto not in cache_variacoes:
                cursor.execute(SQL_GET_VARIACOES_PRODUTO, chave_produto)
                cache_variacoes[chave_produto] = [row.ipr_codigo for row in cursor.fetchall()]
            
            variacoes_do_produto = cache_variacoes[chave_produto]
            
            if not variacoes_do_produto:
                logger.warning(f"Pedido {p.ped_codigo}: Produto {chave_produto} não possui variações (ipr_codigo) cadastradas e será ignorado nos itens do pedido.")
                continue

            # Para cada variação encontrada, cria uma linha de inserção
            for ipr_codigo_encontrado in variacoes_do_produto:
                for fil_codigo, fator_quantidade in item.fatores_filial.items():
                    params_item_ped.append((
                        p.ped_codigo, 
                        item.sec_codigo, 
                        item.esp_codigo, 
                        item.prd_codigo, 
                        ipr_codigo_encontrado, # <-- USA A VARIAÇÃO ENCONTRADA
                        fil_codigo, 
                        1, # ipd_pack
                        fator_quantidade, # ipd_qtde_pedido
                        item.custo, # ipd_valor_custo
                        1, # ipd_fator_grade
                        fator_quantidade # ipd_fator_filial
                    ))

    # Log detalhado dos dados a serem inseridos (visível apenas em modo DEBUG)
    if DEBUG and params_pedido:
        log_msgs = ["\n" + "="*20 + " DEBUG INSERT tb_pedido " + "="*20]
        log_msgs.append(f"Query: {SQL_INSERT_PEDIDO}")
        colunas = ['ped_codigo', 'pes_codigo', 'usu_codigo_comprador', 'ped_data_emissao', 'ped_data_entrega_inicial', 'ped_data_entrega_final', 'ped_status', 'ped_observacao', 'ped_codigo_original', 'ped_qualidade', 'cpg_codigo', 'ped_data_cadastro', 'usu_codigo_cadastro', 'ped_data_ult_alteracao']
        log_msgs.append(f"\nTentando inserir {len(params_pedido)} registro(s):")
        for i, registro in enumerate(params_pedido):
            log_msgs.append(f"\n--- Registro {i+1} ---")
            valores_completos = registro[:6] + ('D',) + registro[6:]
            for col, val in zip(colunas, valores_completos):
                log_msgs.append(f"  - {col}: {val} (Tipo: {type(val).__name__})")
        log_msgs.append("="*58 + "\n")
        logger.debug("\n".join(log_msgs))

    if params_pedido: cursor.executemany(SQL_INSERT_PEDIDO, params_pedido)
    if params_ped_prod: cursor.executemany(SQL_INSERT_PEDIDO_PRODUTO, params_ped_prod)
    if params_item_ped: cursor.executemany(SQL_INSERT_ITEM_PEDIDO, params_item_ped)
    if params_tipo_doc:
        codigos_para_deletar = list(set([item[0] for item in params_tipo_doc]))
        cursor.executemany(SQL_DELETE_TIPO_DOCUMENTO, [(c,) for c in codigos_para_deletar])
        cursor.executemany(SQL_INSERT_TIPO_DOCUMENTO, params_tipo_doc)
    return len(params_pedido)

def cadastrar_pedido(excel_path: str):
    start_total = time.time()
    if not excel_path: return
    try:
        df = pd.read_excel(excel_path, sheet_name=PEDIDO_SHEET_NAME, skiprows=PEDIDO_DATA_START_ROW - 1, header=None).dropna(how='all')
        if df.empty:
            logger.info("Nenhum dado de pedido válido encontrado na planilha.")
            return

        pedidos_a_inserir = []
        pedidos_inseridos = 0
        with get_db_connection(commit_on_exit=True) as conn:
            cursor = conn.cursor()
            proximo_ped_codigo = cursor.execute(SQL_GET_MAX_PEDIDO_CODIGO).fetchone()[0] + 1
            filiais = [row.fil_codigo for row in cursor.execute(SQL_GET_FILIAIS).fetchall()]
            
            pedidos_a_inserir = _prepare_pedidos_from_excel(df, filiais, proximo_ped_codigo)
            logger.info(f"Total de {len(pedidos_a_inserir)} pedidos preparados da planilha.")

            for i in range(0, len(pedidos_a_inserir), BATCH_SIZE):
                batch = pedidos_a_inserir[i:i + BATCH_SIZE]
                pedidos_inseridos += _insert_pedidos_em_lote(cursor, batch)
                logger.info(f"Lote {i//BATCH_SIZE + 1} de pedidos inserido no banco.")
        
        resumo_header = "\n--- Resumo do Cadastro de Pedidos ---"
        resumo_aptos = f"- Pedidos na planilha (aptos): {len(pedidos_a_inserir)}"
        resumo_inseridos = f"- Novos pedidos inseridos:      {pedidos_inseridos}"

        logger.info(resumo_header)
        logger.info(resumo_aptos)
        logger.info(resumo_inseridos)
        
        if pedidos_a_inserir:
            codigos_gerados = [str(p.ped_codigo) for p in pedidos_a_inserir]
            resumo_codigos = f"- Códigos de Pedido Gerados: {', '.join(codigos_gerados)}"
            logger.info(resumo_codigos)

    except Exception as e:
        logger.critical(f"ERRO CRÍTICO em cadastrar_pedido: {e}")
        logger.exception("Rastreamento completo do erro:")
    finally:
        logger.info(f"Tempo total (Pedidos): {time.time() - start_total:.2f}s")

# ==============================================================================
# --- BLOCO DE EXECUÇÃO PRINCIPAL ---
# ==============================================================================
if __name__ == '__main__':
    caminho_do_excel = "Cadastros Auto Nextt Importacao.xlsm"
    
    logger.info("="*50)
    logger.info("INÍCIO DO PROCESSO DE IMPORTAÇÃO")
    
    if not os.path.exists(caminho_do_excel):
        logger.critical(f"ERRO: Arquivo de importação '{caminho_do_excel}' não encontrado.")
    elif not os.path.exists(ARQUIVO_CONEXAO):
        logger.critical(f"ERRO: Arquivo de conexão '{ARQUIVO_CONEXAO}' não encontrado.")
    else:
        logger.info("--- INICIANDO CADASTRO DE PRODUTOS ---")
        cadastrar_produto(caminho_do_excel)
        
        logger.info("\n" + "="*40 + "\n")
        
        logger.info("--- INICIANDO CADASTRO DE PEDIDOS ---")
        cadastrar_pedido(caminho_do_excel)

    logger.info("FIM DO PROCESSO DE IMPORTAÇÃO")
    logger.info("="*50)