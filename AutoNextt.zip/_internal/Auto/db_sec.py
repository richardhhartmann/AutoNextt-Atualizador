import pandas as pd
import pyodbc
import json
import os
import sys

def recurso_path(rel_path):
    """Garante que o caminho funcione no .exe e no modo script."""
    try:
        base_path = sys._MEIPASS  # Quando é executável
    except Exception:
        base_path = os.path.abspath(".")  # Quando é script
    
    # Normaliza o caminho para lidar com ../ ou caminhos relativos
    full_path = os.path.join(base_path, rel_path)
    return os.path.normpath(full_path)


def get_connection_from_file(base_folder, file_name='conexao_temp.txt'):
    """Lê o arquivo JSON na mesma pasta da planilha e cria a conexão."""
    try:
        file_path = os.path.join(base_folder, file_name)

        print(f"[LOG] Usando arquivo de conexão em: {file_path}")

        with open(file_path, 'r', encoding='utf-8') as f:
            config = json.load(f)

        driver = config.get('driver')
        server = config.get('server')
        database = config.get('database')
        username = config.get('username')
        password = config.get('password')
        trusted_connection = config.get('trusted_connection')

        if trusted_connection and trusted_connection.lower() == 'yes':
            string_connection = f"DRIVER={{{driver}}};SERVER={server};DATABASE={database};Trusted_Connection={trusted_connection}"
        else:
            string_connection = f"DRIVER={{{driver}}};SERVER={server};DATABASE={database};UID={username};PWD={password};"

        connection = pyodbc.connect(string_connection)
        cursor = connection.cursor()

        return connection, cursor

    except Exception as e:
        print(f"Erro ao conectar ao banco de dados: {e}")
        sys.exit(1)


# 📄 Verifica se recebeu o caminho da planilha como argumento
if len(sys.argv) > 1:
    caminho_arquivo = os.path.abspath(sys.argv[1])
    pasta_arquivo = os.path.dirname(caminho_arquivo)
else:
    print("Erro: Nenhum caminho de arquivo foi passado.")
    sys.exit(1)

print(f"[LOG] Usando o arquivo de dados: {caminho_arquivo}")

# 🔗 Conectar usando o conexao_temp.txt da mesma pasta da planilha
connection, cursor = get_connection_from_file(pasta_arquivo, 'conexao_temp.txt')


try:
    print("Lendo dados do Excel...")
    df = pd.read_excel(caminho_arquivo, sheet_name="Cadastro de Secao", skiprows=5, usecols="A,C")
    df.columns = ['descricao', 'seg_codigo']

    df = df.dropna(subset=['seg_codigo'])
    df['seg_codigo'] = df['seg_codigo'].astype(int)

    for _, row in df.iterrows():
        descricao = str(row['descricao'])[:50] if pd.notna(row['descricao']) else "Descrição não informada"
        seg_codigo = int(row['seg_codigo'])

        cursor.execute("SELECT MAX(sec_codigo) FROM tb_secao")
        resultado = cursor.fetchone()
        maior_sec_codigo = resultado[0] if resultado[0] is not None else 0

        sec_codigo_incrementado = maior_sec_codigo + 1

        cursor.execute("""
            INSERT INTO tb_secao (
                sec_codigo, sec_descricao, seg_codigo, 
                sec_permite_item_produto, sec_ativo, usu_codigo_comprador, clf_codigo
            ) 
            VALUES (?, ?, ?, 1, 1, 1, NULL)
        """, sec_codigo_incrementado, descricao, seg_codigo)

        connection.commit()
        print(f"Seção '{descricao}' inserida com sec_codigo {sec_codigo_incrementado} no segmento {seg_codigo}.")

    print("\nDados inseridos com sucesso!")

except Exception as e:
    print(f"\nOcorreu um erro: {e}")
    connection.rollback()

finally:
    cursor.close()
    connection.close()