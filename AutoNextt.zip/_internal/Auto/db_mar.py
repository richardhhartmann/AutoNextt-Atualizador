import pandas as pd
import pyodbc
import json
import os
import sys

def recurso_path(rel_path):
    """Garante que o caminho funcione no .exe e no modo script."""
    try:
        base_path = sys._MEIPASS  # Quando é executável
    except Exception:
        base_path = os.path.abspath(".")  # Quando é script
    
    # Normaliza o caminho para lidar com ../ ou caminhos relativos
    full_path = os.path.join(base_path, rel_path)
    return os.path.normpath(full_path)

def get_connection_from_file(file_name='conexao_temp.txt', caminho_arquivo=None):
    """Lê o arquivo JSON da mesma pasta da planilha e cria conexão."""
    try:
        if caminho_arquivo is None:
            raise ValueError("Caminho do arquivo Excel não informado para localizar o conexao_temp.txt.")
        
        # Descobre a pasta onde está a planilha
        pasta_da_planilha = os.path.dirname(os.path.abspath(caminho_arquivo))
        file_path = os.path.join(pasta_da_planilha, file_name)

        print(f"[LOG] Usando arquivo de conexão em: {file_path}")

        with open(file_path, 'r', encoding='utf-8') as f:
            config = json.load(f)

        driver = config.get('driver', None)
        server = config.get('server', None)
        database = config.get('database', None)
        username = config.get('username', None)
        password = config.get('password', None)
        trusted_connection = config.get('trusted_connection', None)

        if trusted_connection and trusted_connection.lower() == 'yes':
            string_connection = f"DRIVER={{{driver}}};SERVER={server};DATABASE={database};Trusted_Connection={trusted_connection}"
        else:
            string_connection = f"DRIVER={{{driver}}};SERVER={server};DATABASE={database};UID={username};PWD={password};"

        connection = pyodbc.connect(string_connection)
        cursor = connection.cursor()

        return connection, cursor

    except Exception as e:
        print(f"Erro ao conectar ao banco de dados: {e}")
        sys.exit(1)

if len(sys.argv) > 1:
    caminho_arquivo = os.path.abspath(sys.argv[1])
else:
    print("Erro: Nenhum caminho de arquivo foi passado.")
    sys.exit(1)

print(f"[LOG] Usando a planilha: {caminho_arquivo}")

connection, cursor = get_connection_from_file('conexao_temp.txt', caminho_arquivo)

try:
    print("Lendo dados do Excel...")
    df = pd.read_excel(caminho_arquivo, sheet_name="Cadastro de Marcas", skiprows=5, usecols="A")
    df.columns = ['descricao']

    df = df.dropna(subset=['descricao'])

    for _, row in df.iterrows():
        descricao = str(row['descricao'])[:50] if pd.notna(row['descricao']) else "Descrição não informada"

        cursor.execute("SELECT MAX(mar_codigo) FROM tb_marca")
        resultado = cursor.fetchone()
        maior_mar_codigo = resultado[0] if resultado[0] is not None else 0

        mar_codigo_incrementado = maior_mar_codigo + 1

        cursor.execute("""
            INSERT INTO tb_marca (mar_codigo, mar_descricao) VALUES (?, ?)
        """, mar_codigo_incrementado, descricao)

        connection.commit()
        print(f"Marca '{descricao}' inserida com mar_codigo {mar_codigo_incrementado}.")

    print("\nDados inseridos com sucesso!")

except Exception as e:
    print(f"\nOcorreu um erro: {e}")
    connection.rollback()

finally:
    cursor.close()
    connection.close()