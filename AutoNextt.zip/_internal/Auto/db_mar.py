import pandas as pd
import pyodbc
import json
import os
import sys

def get_connection_from_file(file_name='conexao_temp.txt', caminho_arquivo=None):
    """Lê o arquivo JSON da mesma pasta da planilha e cria conexão."""
    try:
        if caminho_arquivo is None:
            raise ValueError("Caminho do arquivo Excel não informado para localizar o conexao_temp.txt.")
        
        pasta_da_planilha = os.path.dirname(os.path.abspath(caminho_arquivo))
        file_path = os.path.join(pasta_da_planilha, file_name)

        print(f"[LOG] Usando arquivo de conexão em: {file_path}")

        with open(file_path, 'r', encoding='utf-8') as f:
            config = json.load(f)

        if config.get('trusted_connection', '').lower() == 'yes':
            conn_str = f"DRIVER={{{config['driver']}}};SERVER={config['server']};DATABASE={config['database']};Trusted_Connection=yes;Encrypt=yes;TrustServerCertificate=yes"
        else:
            conn_str = f"DRIVER={{{config['driver']}}};SERVER={config['server']};DATABASE={config['database']};UID={config['username']};PWD={config['password']};Encrypt=yes;TrustServerCertificate=yes"
        
        # Atributo autocommit=False para controlar a transação manualmente
        return pyodbc.connect(conn_str, autocommit=False)

    except FileNotFoundError:
        print(f"[ERRO] Arquivo de conexão '{file_path}' não encontrado.")
        sys.exit(1)
    except Exception as e:
        print(f"[ERRO] Falha ao conectar ao banco de dados: {e}")
        sys.exit(1)

def main():
    """
    Função principal para ler marcas de uma planilha Excel e inseri-las em lote no banco de dados.
    """
    if len(sys.argv) < 2:
        print("[ERRO] O caminho para o arquivo da planilha deve ser fornecido como argumento.")
        sys.exit(1)

    caminho_arquivo = os.path.abspath(sys.argv[1])
    print(f"[LOG] Processando a planilha: {caminho_arquivo}")

    # --- 1. Leitura e Preparação dos Dados com Pandas ---
    try:
        df = pd.read_excel(
            caminho_arquivo, 
            sheet_name="Cadastro de Marcas", 
            skiprows=5, 
            usecols="A",
            header=None, # Não há cabeçalho na linha 6
            names=['descricao'] # Nomeia a coluna diretamente
        )
        
        # Limpeza de dados de forma vetorizada (muito mais rápido que um loop)
        df.dropna(subset=['descricao'], inplace=True)
        df['descricao'] = df['descricao'].astype(str).str.strip().str.slice(0, 50)
        df.drop_duplicates(subset=['descricao'], inplace=True)

        if df.empty:
            print("[INFO] Nenhuma marca nova para inserir foi encontrada na planilha.")
            sys.exit(0)

        print(f"[INFO] {len(df)} novas marcas encontradas para importação.")

    except Exception as e:
        print(f"[ERRO] Falha ao ler ou processar o arquivo Excel: {e}")
        sys.exit(1)

    connection = None
    try:
        # --- 2. Operações de Banco de Dados em Lote ---
        connection = get_connection_from_file('conexao_temp.txt', caminho_arquivo)
        cursor = connection.cursor()

        # Pega o código máximo APENAS UMA VEZ
        print("[LOG] Buscando o código máximo de marca existente...")
        cursor.execute("SELECT MAX(mar_codigo) FROM tb_marca")
        maior_mar_codigo = cursor.fetchone()[0] or 0 # Usa 'or 0' se a tabela estiver vazia

        # Prepara a lista de tuplas para inserção em lote
        dados_para_inserir = []
        prox_codigo = maior_mar_codigo + 1
        
        for descricao in df['descricao']:
            dados_para_inserir.append((prox_codigo, descricao))
            prox_codigo += 1

        # --- 3. Inserção em Lote (Bulk Insert) ---
        sql_insert = "INSERT INTO tb_marca (mar_codigo, mar_descricao) VALUES (?, ?)"
        
        print(f"[LOG] Iniciando inserção em lote de {len(dados_para_inserir)} registros...")
        cursor.executemany(sql_insert, dados_para_inserir)

        # --- 4. Commit da Transação (Apenas uma vez) ---
        connection.commit()
        print(f"\n[SUCESSO] {len(dados_para_inserir)} marcas foram inseridas com sucesso!")

    except Exception as e:
        print(f"\n[ERRO] Ocorreu um erro durante a operação com o banco de dados: {e}")
        if connection:
            print("[LOG] Revertendo a transação (rollback)...")
            connection.rollback()
    finally:
        if connection:
            connection.close()
            print("[LOG] Conexão com o banco de dados fechada.")

if __name__ == '__main__':
    main()